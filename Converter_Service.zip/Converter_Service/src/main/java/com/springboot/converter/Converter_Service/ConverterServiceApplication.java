package com.springboot.converter.Converter_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConverterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConverterServiceApplication.class, args);
	}

}
