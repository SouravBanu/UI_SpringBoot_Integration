package com.cts.servicevalidator.contants;

public class UIConstants {
	public static final String WEBROOT= "C:\\webroot\\testharness";
//	public static String WEBROOT= "C:\\webroot\\testharness"+File.separator+ServiceValidatorAction.getTenantname();
	public static final String DEFAULT_USER_FILE="userprofile.properties";
}
