package com.cts.integration.dto;

import junit.framework.TestCase;

public class IJunitTestCase {

	public static TestCaseDTO testCase;

	public static TestCaseDTO getTestCase() {
		return testCase;
	}

	public static void setTestCase(TestCaseDTO testCase) {
		IJunitTestCase.testCase = testCase;
	}}
