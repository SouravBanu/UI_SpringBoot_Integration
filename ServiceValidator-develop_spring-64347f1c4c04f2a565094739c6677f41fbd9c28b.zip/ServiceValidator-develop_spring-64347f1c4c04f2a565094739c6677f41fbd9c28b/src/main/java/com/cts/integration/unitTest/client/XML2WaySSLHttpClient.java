package com.cts.integration.unitTest.client;

import com.cts.integration.dto.RequestDTO;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLContext;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

public class XML2WaySSLHttpClient {
  public static String invokeService(RequestDTO request) throws FileNotFoundException, IOException, KeyStoreException, CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyManagementException {
    BufferedReader bufferedReader = null;
    FileReader fr = null;
    FileInputStream kis = null;
    HttpClient httpClient = null;
    try {
      CloseableHttpClient closeableHttpClient;
      StringBuffer requestFileContents = new StringBuffer();
      fr = new FileReader(request.getRequestPath());
      bufferedReader = new BufferedReader(fr);
      String line = null;
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      if (request.isSecured() && "CERT".equalsIgnoreCase(request.getSecurityType())) {
        KeyStore keyStore = KeyStore.getInstance(request.getKeystoreType());
        kis = new FileInputStream(request.getCertPath());
        keyStore.load(kis, "changeit".toCharArray());
        SSLContext sslContext = SSLContexts.custom().loadKeyMaterial(keyStore, request.getKeystorePass().toCharArray()).build();
        closeableHttpClient = HttpClients.custom().setSslcontext(sslContext).build();
      } else if (request.isSecured() && "BASIC".equalsIgnoreCase(request.getSecurityType())) {
        BasicCredentialsProvider basicCredentialsProvider = new BasicCredentialsProvider();
        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(request.getUserName(), request.getPassword());
        basicCredentialsProvider.setCredentials(AuthScope.ANY, (Credentials)credentials);
        closeableHttpClient = HttpClientBuilder.create().setDefaultCredentialsProvider((CredentialsProvider)basicCredentialsProvider).build();
      } else {
        closeableHttpClient = HttpClientBuilder.create().build();
      } 
      HttpPost httppost = new HttpPost(request.getServiceURL());
      httppost.setHeader("Accept", "application/soap+xml,application/dime,multipart/related,text/*");
      httppost.setHeader("SOAPAction", "");
      StringEntity se = new StringEntity(requestFileContents.toString());
      httppost.setEntity((HttpEntity)se);
      HttpResponse httpResponse = closeableHttpClient.execute((HttpUriRequest)httppost);
      String response = EntityUtils.toString(httpResponse.getEntity());
      return response;
    } finally {
      if (fr != null)
        fr.close(); 
      if (bufferedReader != null)
        bufferedReader.close(); 
      if (kis != null)
        kis.close(); 
    } 
  }
  
  public static String invokeService(String wsURL, String requestXMLPath, String source) throws FileNotFoundException, IOException, KeyStoreException, CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyManagementException {
    BufferedReader bufferedReader = null;
    FileReader fr = null;
    FileInputStream kis = null;
    HttpClient httpClient = null;
    try {
      StringBuffer requestFileContents = new StringBuffer();
      fr = new FileReader(requestXMLPath);
      bufferedReader = new BufferedReader(fr);
      String line = null;
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      KeyStore keyStore = KeyStore.getInstance("JKS");
      kis = new FileInputStream(String.valueOf(source) + File.separator + "clientCertAndKey" + File.separator + "clientks.jks");
      keyStore.load(kis, "changeit".toCharArray());
      SSLContext sslContext = SSLContexts.custom().loadKeyMaterial(keyStore, "changeit".toCharArray()).build();
      CloseableHttpClient closeableHttpClient = HttpClients.custom().setSslcontext(sslContext).build();
      HttpPost httppost = new HttpPost(wsURL);
      httppost.setHeader("Accept", "application/soap+xml,application/dime,multipart/related,text/*");
      httppost.setHeader("SOAPAction", "");
      StringEntity se = new StringEntity(requestFileContents.toString());
      httppost.setEntity((HttpEntity)se);
      HttpResponse httpResponse = closeableHttpClient.execute((HttpUriRequest)httppost);
      String response = EntityUtils.toString(httpResponse.getEntity());
      return response;
    } finally {
      if (fr != null)
        fr.close(); 
      if (bufferedReader != null)
        bufferedReader.close(); 
      if (kis != null)
        kis.close(); 
    } 
  }
}
