package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.DigitalSignatureDTO;
import com.cts.integration.dto.ISecurityDTO;
import com.cts.integration.factory.HTTPSecurityFactory;
import com.cts.integration.security.IHTTPSecurity;
import com.cts.integration.util.AdvancedDigitalSignatureUtility;
import com.cts.integration.util.FileUtil;
import java.io.File;
import java.io.FileInputStream;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

public class HTTPAdvancedClient implements IJunitClient {
  static Logger log = Logger.getLogger(HTTPAdvancedClient.class.getName());
 
  public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("HTTP clinet->put ");
    FileInputStream kis = null;
    HttpClient httpClient = null;
    Properties securityProperties = new Properties();
    Properties digsigProperties = new Properties();
    // Adding Header Properties -- NML
    Properties headerProperties = new Properties();
    String key = null,value = null;
	ArrayList objList = new ArrayList();
	HashMap<String,String> map = new HashMap<String,String>();	
    FileInputStream propInputStream = null;
    FileInputStream digSigPropInputStream = null;
    ISecurityDTO securityDTO = new ISecurityDTO();
    DigitalSignatureDTO digsigDTO = new DigitalSignatureDTO();
    String response = null;
    boolean isHttps = false;
    if (complexRequestDTO.getUrl().startsWith("https"))
      isHttps = true; 
    boolean createClient = false;
    try {
      CloseableHttpClient closeableHttpClient = null;
      String securityFileLocation = complexRequestDTO.getSecurityFile();
      if (securityFileLocation != null) {
        File securityPropFile = new File(securityFileLocation);
        if (securityPropFile.exists()) {
          log.info("Security file exists");
          propInputStream = new FileInputStream(securityPropFile);
          securityProperties.load(propInputStream);
          securityDTO.setValueFromProperties(securityProperties, complexRequestDTO.getTestCase());
          IHTTPSecurity httpSecurity = HTTPSecurityFactory.getHTTPSecurityByType(securityDTO.getType());
          if (httpSecurity != null) {
            httpClient = httpSecurity.registerSecurity(complexRequestDTO, securityDTO);
            
            log.info("Registerred " + httpSecurity);
          } else {
            createClient = true;
            log.info(" No security type available");
          } 
        } else {
          log.info(" No security file exists");
          createClient = true;
        } 
      } else {
        log.info(" No security");
        createClient = true;
      } 
      if (createClient && !isHttps) {
        closeableHttpClient = HttpClientBuilder.create().build();
      } else if (createClient && isHttps) {
        log.info(" SSL required ");
        SSLContextBuilder builder = new SSLContextBuilder();
        builder.loadTrustMaterial(null, new TrustStrategy() {
              public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                return true;
              }
            });
        SSLConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(builder.build(), 
            SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        closeableHttpClient = HttpClients.custom().setSSLSocketFactory((LayeredConnectionSocketFactory)sslSF).build();
      } 
      log.info(" HttpClient created");
      String digitalSignatureFile = complexRequestDTO.getDigitalSignatureFile();
      if (digitalSignatureFile != null) {
        File digsigPropFile = new File(digitalSignatureFile);
        if (digsigPropFile.exists()) {
          log.info("Digital signature file exists");
          digSigPropInputStream = new FileInputStream(digsigPropFile);
          digsigProperties.load(digSigPropInputStream);
          digsigDTO.setInputFile(complexRequestDTO.getTestInputFileLocation());
          digsigDTO.setValueFromProperties(digsigProperties, complexRequestDTO.getTestCase());
          complexRequestDTO.setMessage(AdvancedDigitalSignatureUtility.digitallySign(digsigDTO));
          log.info("Digital signature added");
          System.out.println("Digitally signed content " + complexRequestDTO.getMessage());
        } else {
          log.info(" No digital signature file exists");
        } 
      } 
      if ("GET".equalsIgnoreCase(complexRequestDTO.getHttpMethod())) {
        log.info(" HTTP GET Method ");
        
        HttpGet httpget = new HttpGet(complexRequestDTO.getUrl().trim());
        // Adding for header properties.
        String headerFileLocation = complexRequestDTO.getHeaderFile();
        if (headerFileLocation != null) {
            File headerPropFile = new File(headerFileLocation);
            if (headerPropFile.exists()) {
              log.info("Header file exists");
              propInputStream = new FileInputStream(headerPropFile);
              headerProperties.load(propInputStream);
              
          	Enumeration objEn = headerProperties.keys();
			while(objEn.hasMoreElements()) 
			{
				key = objEn.nextElement().toString();
				value = headerProperties.getProperty(key.toString());
				log.info(" Setting http request headers");
		          httpget.addHeader(key, value);
		          
			}
              }
            else {
                  log.info(" No header file exists");                  
                } 
              } else {
                log.info(" No header");                
              } 
        if ("json".equalsIgnoreCase(complexRequestDTO.getTargetFormat())) {
          log.info(" Setting request format JSON ");
          httpget.setHeader("content-type", "application/json");
          httpget.setHeader("Accept", "application/json");
         // httpget.setHeader("Authorization", complexRequestDTO.getAuthorization());
        } else if ("xml".equalsIgnoreCase(complexRequestDTO.getTargetFormat())) {
          log.info(" Setting request format XML ");
          httpget.setHeader("Accept", "application/soap+xml,application/dime,multipart/related,text/*");
          httpget.setHeader("SOAPAction", "");
         // httpget.setHeader("Authorization", complexRequestDTO.getAuthorization());
        } 
        System.out.println(" =============================================================HTTP GET Request =============================================================================== ");
        System.out.println(" http get request header:  " +httpget);
        System.out.println(" http get request :  " +httpget);
        HttpResponse httpResponse = closeableHttpClient.execute((HttpUriRequest)httpget);
        response = EntityUtils.toString(httpResponse.getEntity());        
        System.out.println(" =============================================================HTTP GET Response=============================================================================== ");
        System.out.println(" http get response :  " +response);        
        log.info(" http call executed ");
      } else {
        log.info(" HTTP POST Method ");
        String requestFileContents = complexRequestDTO.getMessage();        
        HttpPost httppost = new HttpPost(complexRequestDTO.getUrl().trim());        
        // Adding for header properties.
        String headerFileLocation = complexRequestDTO.getHeaderFile();
        if (headerFileLocation != null) {
            File headerPropFile = new File(headerFileLocation);
            if (headerPropFile.exists()) {
              log.info("Header file exists");
              propInputStream = new FileInputStream(headerPropFile);
              headerProperties.load(propInputStream);
              
          	Enumeration objEn = headerProperties.keys();
			while(objEn.hasMoreElements()) 
			{
				key = objEn.nextElement().toString();
				value = headerProperties.getProperty(key.toString());
				log.info(" Setting http request headers");
		          httppost.addHeader(key, value); 
				
			}
              }
            else {
                  log.info(" No header file exists");                  
                } 
              } else {
                log.info(" No header");                
              } 
        if ("json".equalsIgnoreCase(complexRequestDTO.getTargetFormat())) {
          log.info(" Setting request format JSON ");
          httppost.setHeader("content-type", "application/json");
          httppost.setHeader("Accept", "application/json");
          //httppost.setHeader("Authorization", complexRequestDTO.getAuthorization());
        } else if ("xml".equalsIgnoreCase(complexRequestDTO.getTargetFormat())) {
          log.info(" Setting request format XML ");
          httppost.setHeader("Accept", "application/soap+xml,application/dime,multipart/related,text/*");
          httppost.setHeader("SOAPAction", "");
          
          //httppost.setHeader("Authorization", complexRequestDTO.getAuthorization());
        } 
        StringEntity se = new StringEntity(requestFileContents.toString());
        httppost.setEntity((HttpEntity)se);         
        System.out.println(" =============================================================HTTP POST Request =============================================================================== ");
        System.out.println(" http post request :  " +httppost.getEntity());
        HttpResponse httpResponse = closeableHttpClient.execute((HttpUriRequest)httppost);
        response = EntityUtils.toString(httpResponse.getEntity());
        System.out.println(" =============================================================HTTP POST Response =============================================================================== ");
        System.out.println(" http post response :  " +response);
        log.info(" HTTP GET Executed ");
      } 
      complexRequestDTO.setResponse(response);
      FileUtil.writeToFile(complexRequestDTO.getTestOutputFileLocation(), complexRequestDTO.getResponse());
    } finally {
      if (propInputStream != null)
        propInputStream.close(); 
      if (kis != null)
        kis.close(); 
    } 
  }
  
  public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("HTTPClient->Get a response");
    put(complexRequestDTO);
  }
  
  public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO) throws Exception {}
  
  public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Synchronous HTTP Call");
    put(complexRequestDTO);
  }


}
