package com.cts.integration.unitTest.client;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import javax.xml.ws.http.HTTPException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.json.JSONArray;
import org.json.JSONObject;

public class PostJSONClient {
  public static void main(String[] a) throws HttpException, IOException, Exception {
    System.out.println("Response : " + invokeJSONService("http://10.255.161.88:7080/json/service", "D:/UnitTest/jsonResponse/test1/test1Expected.json"));
  }
  
  public static Object invokeJSONService(String jsonURL, String jsonRequestPath) throws FileNotFoundException, Exception {
    PostMethod post = null;
    HttpClient client = new HttpClient();
    BufferedReader bufferedReader = null;
    FileReader fr = null;
    try {
      StringBuffer requestFileContents = new StringBuffer();
      fr = new FileReader(jsonRequestPath);
      bufferedReader = new BufferedReader(fr);
      String line = null;
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      post = new PostMethod(jsonURL);
      post.setRequestHeader("content-type", "application/json");
      post.setRequestHeader("Accept", "application/json");
      StringRequestEntity stringRequestEntity = new StringRequestEntity(requestFileContents.toString());
      post.setRequestEntity((RequestEntity)stringRequestEntity);
      int result = client.executeMethod((HttpMethod)post);
      String response = post.getResponseBodyAsString();
      JSONObject jsonObj = null;
      JSONArray jarray = null;
      if (response.trim().startsWith("[")) {
        jarray = new JSONArray(response);
        return jarray;
      } 
      jsonObj = new JSONObject(response);
      return jsonObj;
    } finally {
      if (post != null)
        post.releaseConnection(); 
      if (fr != null)
        fr.close(); 
      if (bufferedReader != null)
        bufferedReader.close(); 
    } 
  }
}
