package com.cts.integration.unitTest.executer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.Set;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import com.cts.integration.unitTest.testCase.XMLHttpWebserviceTestCase;

public class XMLHttpWebserviceExecuter {

	/**
	 * @param args
	 */
	/*public static void main(String[] args) throws FileNotFoundException, Exception{
		// TODO Auto-generated method stub
		//Properties prop;
		Properties wsProp = new Properties();
		Properties asIsProp = new Properties();
		//InputStream is = null;
		InputStream wsInput=null;
		InputStream asisInput=null;
		PrintWriter writer = null;
		//System.out.println(" system source "+System.getProperty("RootSource"));
		
		JUnitCore junit = new JUnitCore();
		try{
			String source;
			prop = new Properties();
	        is = PostJSONExecuter.class.getResourceAsStream("/test.properties");
	        prop.load(is);
	        //source = prop.getProperty("folder");
	        source=System.getProperty("RootSource");
	        if(source == null || source.trim().length()==0){
	        	source = System.getProperty("user.dir")+File.separator;
	        }
	        
	        wsInput = new FileInputStream(source+"xmlHttpWebservice"+File.separator+"url.properties");
	        wsProp.load(wsInput);
	        XMLHttpWebserviceTestCase.source = source;
	        
	        File asisUrlProperties = new File(source+"xmlHttpWebservice"+File.separator+"legacy_url.properties");
	        if(asisUrlProperties.exists()){
	        	asisInput = new FileInputStream(asisUrlProperties);
	        	asIsProp.load(asisInput) ;
	        }
	        
	        writer = new PrintWriter(source+"xmlHttpWebservice"+File.separator+"Report.txt", "UTF-8");
	        
	        Set<Object> keys = wsProp.keySet();
	        for(Object k:keys){
	        	String testName = (String)k;
	            String wsURL = wsProp.getProperty(testName);
	            String asIsUrl = asIsProp.getProperty(testName);
	            
	            XMLHttpWebserviceTestCase.testName = testName;
	            XMLHttpWebserviceTestCase.wsURL= wsURL;
	            XMLHttpWebserviceTestCase.asIsURL = asIsUrl;
	            
	           
	            Result result = junit.run(XMLHttpWebserviceTestCase.class);
	            //log.debug("Test case result for : "+testName+" result "+result.wasSuccessful());
	            System.out.println("Test case result for : "+testName+" result "+result.wasSuccessful());
	            writer.println("Test Case : "+testName+"| Result : "+result.wasSuccessful());
	            if(!result.wasSuccessful()){
	            	writer.println("Failure :"+result.getFailures());
	            }
	        }
			
		}finally{
			if(is !=null){
				is.close();
			}
			if(wsInput != null){
				wsInput.close();
			}
			if(asisInput != null){
				asisInput.close();
			}
			if(writer != null){
				writer.close();
			}
		}

	}*/

}
