package com.cts.integration.unitTest.client;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetJSONClient {
  public static String readAll(Reader rd) throws IOException {
    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = rd.read()) != -1)
      sb.append((char)cp); 
    return sb.toString();
  }
  
  public static Object readJsonFromUrl(String urlstr) throws IOException, JSONException {
    URL url = new URL(urlstr);
    URLConnection urlc = url.openConnection();
    urlc.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0a2) Gecko/20110613 Firefox/6.0a2");
    InputStream is = url.openStream();
    JSONObject jsonObj = null;
    JSONArray jarray = null;
    try {
      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
      String jsonText = readAll(rd);
      if (jsonText.trim().startsWith("[")) {
        jarray = new JSONArray(jsonText);
        return jarray;
      } 
      jsonObj = new JSONObject(jsonText);
      return jsonObj;
    } finally {
      is.close();
    } 
  }
  
  public static void main(String[] args) throws IOException, JSONException {
    String json = "{\"menu\": {\"header\": \"SVG Viewer\",\"items\": [{\"id\": \"Open\"},{\"id\": \"OpenNew\", \"label\": \"Open New\"}]}}";
    JSONObject jsonObj = new JSONObject(json);
    System.out.println(" jsonObj" + jsonObj);
    String jsonArray = "[{\"id\": \"Open\"},{\"id\": \"OpenNew\", \"label\": \"Open New\"}]";
    JSONArray jarray = new JSONArray(jsonArray);
    System.out.println("jarray :" + jarray);
    JSONObject jarrayObjec = new JSONObject();
    jarrayObjec.put("rootArrya", jarray);
    System.out.println("jarrayObject " + jarrayObjec);
    Reader expectedJSONReader = new InputStreamReader(new FileInputStream("D:/UnitTest/Test2.json"));
    String expectedJSONstr = readAll(expectedJSONReader);
    System.out.println(" expectedJSONstr " + expectedJSONstr);
  }
}
