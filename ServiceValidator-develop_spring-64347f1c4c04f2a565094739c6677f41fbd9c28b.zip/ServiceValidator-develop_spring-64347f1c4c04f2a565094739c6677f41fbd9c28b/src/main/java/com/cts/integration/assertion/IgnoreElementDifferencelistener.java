package com.cts.integration.assertion;

import java.util.ArrayList;
import java.util.List;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.DifferenceListener;
import org.w3c.dom.Node;

class IgnoreElementDifferenceListener implements DifferenceListener {
  private List<String> blackList = new ArrayList<String>();
  
  public IgnoreElementDifferenceListener(List<String> elementNames) {
    this.blackList = elementNames;
  }
  
  public int differenceFound(Difference difference) {
    if (difference.getControlNodeDetail().getNode().getParentNode() != null) {
      String elementWithPrefix = difference.getControlNodeDetail().getNode().getParentNode().getNodeName();
      String prefix = difference.getControlNodeDetail().getNode().getParentNode().getPrefix();
      String elementName = null;
      if (prefix != null && prefix.length() > 0) {
        elementName = elementWithPrefix.substring(prefix.length() + 1);
      } else {
        elementName = elementWithPrefix;
      } 
      if (difference.getId() == 14)
        if (this.blackList.contains(elementName))
          return 1;  
    } 
    return 0;
  }
  
  public void skippedComparison(Node node, Node node1) {}
}
