package com.cts.integration.unitTest.client;

import java.io.File;

import org.apache.log4j.Logger;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.util.FileUtil;

public class FileClient implements IJunitClient {

	static Logger log = Logger.getLogger(FileClient.class.getName());
	@Override
	public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
		log.info("Writing to file input location");
		FileUtil.writeToFile(complexRequestDTO.getLocalDirectory()+complexRequestDTO.getLocalFileName(), complexRequestDTO.getMessage());

	}

	@Override
	public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
		//Thread.sleep(complexRequestDTO.getFileftpWaitInterval());
		log.info("Getting file from target location");
		String latestFile = FileUtil.getLatestMatchingFile(complexRequestDTO.getLocalDirectory(),complexRequestDTO.getLocalFileName());
		if(latestFile == null && System.currentTimeMillis()<(complexRequestDTO.getRequestTimeInMS()+complexRequestDTO.getFileftpWaitInterval())){
			log.info("No File recieved .. Retrying ");
			Thread.sleep(complexRequestDTO.getFilePollInterval());
			get(complexRequestDTO);
		}else{
			log.info("Finished Polling ");
			if(latestFile != null){
				log.info("Reading File ");
				complexRequestDTO.setResponse(FileUtil.readFileAsString(latestFile));
				FileUtil.writeToFile(complexRequestDTO.getTestOutputFileLocation(), complexRequestDTO.getResponse());
			}else throw new Exception("No matching file created ");
		}

	}

	@Override
	public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO)
			throws Exception {
		//FileUtil.purgeDirectoryskipSubDir(new File(complexRequestDTO.getLocalPath().substring(0,complexRequestDTO.getLocalPath().lastIndexOf(File.separator))));
		log.info("Archiving Files in Target directory ");
		FileUtil.purgeAndArchiveDirectorySkipSubDir(new File(complexRequestDTO.getLocalDirectory()));
	}
	
	public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception{
		
	}

}
