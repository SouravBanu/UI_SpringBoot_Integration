package com.cts.integration.unitTest.executer;

import com.cts.integration.dto.TestCaseDTO;
import com.cts.integration.dto.TestConfDTO;
import com.cts.integration.factory.TestCaseFactory;
import com.cts.integration.util.DBUtil;
import com.cts.integration.util.ExcelUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import junit.framework.TestCase;
import junit.framework.TestFailure;
import junit.framework.TestResult;
import org.apache.log4j.Logger;
import org.junit.runner.JUnitCore;

public class IJunitExecuter {
  static Logger log = Logger.getLogger(IJunitExecuter.class.getName());
  
  public static void main(String[] a) throws Exception {
    System.out.println("Service Validator V : 201703071600");
    log.info("================Testing initiated=================");
    IJunitExecuter ex = new IJunitExecuter();
    PrintWriter writer = null;
    PrintWriter csvWriter = null;
    JUnitCore junit = new JUnitCore();
    boolean hasFailure = false;
    boolean hasRerunFailure = false;
    Calendar now = Calendar.getInstance();
    String yymmddhhmmss = String.valueOf((new Integer(now.get(1))).toString()) + (
      new Integer(now.get(2) + 1)).toString() + (
      new Integer(now.get(5))).toString() + (
      new Integer(now.get(10))).toString() + (
      new Integer(now.get(12))).toString() + (
      new Integer(now.get(13))).toString();
    try {
      String csvHeader = "testCase,description,pattern,sourceProtocol,sourceFormat,targetProtocol,targetFormat,securityInfo,endpoint,legacyEndPont,sourceInfo,input,expectedOutput,actualOutput,passed,executedAt,rerun,reason";
      List<TestCaseDTO> testCases = new ArrayList<TestCaseDTO>();
      List<String> failedCases = new ArrayList<String>();
      List<TestCaseDTO> failedTestCases = new ArrayList<TestCaseDTO>();
      List<TestCaseDTO> testCaseReports = new ArrayList<TestCaseDTO>();
      List<String> testCaseXMLReports = new ArrayList<String>();
      TestConfDTO confDTO = null;
      String source = System.getProperty("RootSource");
      if (source == null || source.trim().length() == 0)
        source = String.valueOf(System.getProperty("user.dir")) + File.separator; 
      if (!source.endsWith(File.separator))
        source = String.valueOf(source) + File.separator; 
      log.info("Root directory -> " + source);
      writer = new PrintWriter(String.valueOf(source) + "QuickReport.txt", "UTF-8");
      csvWriter = new PrintWriter(String.valueOf(source) + "Report" + yymmddhhmmss + ".csv", "UTF-8");
      csvWriter.println(csvHeader);
      String inputFileLocation = String.valueOf(source) + "IJUnitTest.xlsx";
      String configFileLocation = String.valueOf(source) + "ijunit.properties";
      confDTO = ex.loadTestConf(configFileLocation);
      testCases = ExcelUtil.readExcel(inputFileLocation);
      int noOfTests = testCases.size();
      log.info("Total Test cases to be executed -> " + (noOfTests - 1));
      for (int testIndex = 1; testIndex < noOfTests; testIndex++) {
        TestCaseDTO testCase = testCases.get(testIndex);
        if (!"INACTIVE".equalsIgnoreCase(testCase.getIsActive())) {
          log.info("==Intialising Test case -> " + testCase.getTestCase());
          testCase.setSource(source);
          ex.setDefault(testCase, source);
          TestCase tc = TestCaseFactory.getTestClass(testCase.getPattern(), testCase);
          TestResult tr = tc.run();
          log.info(String.valueOf(testCase.getTestCase()) + " : " + tr.wasSuccessful());
          System.out.println("Test case result for : " + testCase.getTestCase() + " result " + testCase.translateResult(tr.wasSuccessful()));
          testCase.setPassed(tr.wasSuccessful());
          testCase.setExecutedAt(System.currentTimeMillis());
          writer.println("Test Case : " + testCase.getTestCase() + "| Result : " + testCase.translateResult(tr.wasSuccessful()));
          if (!tr.wasSuccessful()) {
            if (tr.failures().hasMoreElements()) {
              log.info(" Failure reason " + tr.failures().nextElement());
              String reason = ((TestFailure)tr.failures().nextElement()).toString().replaceAll("\\r\\n|\\r|\\n", " ");
              writer.println("Failure :" + ((TestFailure)tr.failures().nextElement()).toString());
              String exMessage = ((TestFailure)tr.failures().nextElement()).exceptionMessage().replaceAll("\\r\\n|\\r|\\n", " ");
              exMessage = exMessage.substring(0, exMessage.indexOf(" "));
              testCase.setReason(reason);
              testCase.setExceptionName(exMessage);
              testCase.setDescription(reason);
            } else {
              log.info("no failure info");
            } 
            if (tr.errors().hasMoreElements()) {
              log.info(" Failure reason " + tr.errors().nextElement());
              String reason = ((TestFailure)tr.errors().nextElement()).toString().replaceAll("\\r\\n|\\r|\\n", " ");
              writer.println("Failure :" + ((TestFailure)tr.errors().nextElement()).toString());
              String exMessage = ((TestFailure)tr.errors().nextElement()).getClass().getName();
              testCase.setReason(reason);
              testCase.setExceptionName(exMessage);
              testCase.setDescription(reason);
            } else {
              log.info("No error info");
            } 
            hasFailure = true;
            failedTestCases.add(testCase);
            if (!"TRUE".equalsIgnoreCase(confDTO.getRetry()))
              failedCases.add(testCase.getTestCase()); 
          } 
          csvWriter.println(testCase.toString());
          testCaseReports.add(new TestCaseDTO(testCase));
          if (tr.wasSuccessful() || (!tr.wasSuccessful() && !"TRUE".equalsIgnoreCase(confDTO.getRetry())))
            testCaseXMLReports.add((new TestCaseDTO(testCase)).toXML()); 
          log.info("==Completed Test Case : " + testCase.getTestCase());
        } 
      } 
      if ("TRUE".equalsIgnoreCase(confDTO.getRetry()) && hasFailure) {
        log.info("==Rerunning failed test cases");
        int failedCasesSize = failedTestCases.size();
        for (int i = 0; i < failedCasesSize; i++) {
          TestCaseDTO testCase = failedTestCases.get(i);
          log.info("==Rerunning Test case -> " + testCase.getTestCase());
          testCase.setRerun(true);
          TestCase tc = TestCaseFactory.getTestClass(testCase.getPattern(), testCase);
          TestResult tr = tc.run();
          log.info(String.valueOf(testCase.getTestCase()) + " Rerun : " + tr.wasSuccessful());
          System.out.println("Rerun Test case result for : " + testCase.getTestCase() + " result " + testCase.translateResult(tr.wasSuccessful()));
          testCase.setPassed(tr.wasSuccessful());
          testCase.setExecutedAt(System.currentTimeMillis());
          writer.println("Rerun Test Case : " + testCase.getTestCase() + "| Result : " + testCase.translateResult(tr.wasSuccessful()));
          if (!tr.wasSuccessful()) {
            if (tr.failures().hasMoreElements()) {
              log.info(" Failure reason " + tr.failures().nextElement());
              String reason = ((TestFailure)tr.failures().nextElement()).toString().replaceAll("\\r\\n|\\r|\\n", " ");
              writer.println("Failure :" + ((TestFailure)tr.failures().nextElement()).toString());
              String exMessage = ((TestFailure)tr.failures().nextElement()).exceptionMessage().replaceAll("\\r\\n|\\r|\\n", " ");
              exMessage = exMessage.substring(0, exMessage.indexOf(" "));
              testCase.setReason(reason);
              testCase.setExceptionName(exMessage);
              testCase.setDescription(reason);
            } else {
              log.info("no failure info");
            } 
            if (tr.errors().hasMoreElements()) {
              log.info(" Failure reason " + tr.errors().nextElement());
              String reason = ((TestFailure)tr.errors().nextElement()).toString().replaceAll("\\r\\n|\\r|\\n", " ");
              writer.println("Failure :" + ((TestFailure)tr.errors().nextElement()).toString());
              String exMessage = ((TestFailure)tr.errors().nextElement()).getClass().getName();
              testCase.setReason(reason);
              testCase.setExceptionName(exMessage);
              testCase.setDescription(reason);
            } else {
              log.info("No error info");
            } 
            hasRerunFailure = true;
            failedCases.add(testCase.getTestCase());
          } 
          csvWriter.println(testCase.toString());
          testCaseReports.add(new TestCaseDTO(testCase));
          testCaseXMLReports.add((new TestCaseDTO(testCase)).toXML());
          log.info("==Completed Test Case rerun : " + testCase.getTestCase());
        } 
      } 
      log.info("Creating XMLReport");
      ex.createXMLReport(testCaseXMLReports, source, failedCases.size(), yymmddhhmmss);
      if ("TRUE".equalsIgnoreCase(confDTO.getDbReporting()))
        DBUtil.reportToDB(confDTO, testCaseReports); 
      if (hasRerunFailure && "TRUE".equalsIgnoreCase(confDTO.getRetry()))
        throw new Exception("One or more test cases have failed with rerun attempt. Please check report. Falied Test cases are " + failedCases.toString()); 
      if (hasFailure && !"TRUE".equalsIgnoreCase(confDTO.getRetry()))
        throw new Exception("One or more test cases have failed. Please check report. Falied Test cases are " + failedCases.toString()); 
    } finally {
      if (writer != null)
        writer.close(); 
      if (csvWriter != null)
        csvWriter.close(); 
    } 
  }
  
  public void setDefault(TestCaseDTO testCase, String source) {
    String testCaseName = testCase.getTestCase().trim();
    File file = null;
    if ("SynchronousWebservice".equals(testCase.getPattern().trim())) {
      testCase.setSourceFormat("xml");
      testCase.setTargetFormat("xml");
    } 
    if ("JSONPost".equals(testCase.getPattern().trim()) || "JSONPost".equals(testCase.getPattern().trim())) {
      testCase.setSourceFormat("json");
      testCase.setTargetFormat("json");
    } 
    if (testCase.getTargetFormat() == null || testCase.getTargetFormat().trim().length() == 0)
      testCase.setTargetFormat(testCase.getSourceFormat()); 
    if (testCase.getInput() == null || testCase.getInput().trim().length() == 0) {
      testCase.setInput(String.valueOf(source) + testCaseName + File.separator + testCaseName + "Input");
    } else {
      file = new File(testCase.getInput().trim());
      if (!file.isAbsolute()) {
        String path = String.valueOf(source) + testCase.getInput().trim();
        testCase.setInput(path);
      } 
    } 
    if (testCase.getExpectedOutput() == null || testCase.getExpectedOutput().trim().length() == 0) {
      if (testCase.getInput().trim().startsWith(String.valueOf(source) + testCaseName)) {
        testCase.setExpectedOutput(String.valueOf(source) + testCaseName + File.separator + testCaseName + "Expected");
      } else {
        testCase.setExpectedOutput(String.valueOf(source) + testCaseName + "Expected" + "." + testCase.getTargetFormat().trim());
      } 
    } else {
      file = new File(testCase.getInput().trim());
      if (!file.isAbsolute()) {
        String path = String.valueOf(source) + testCase.getExpectedOutput().trim();
        testCase.setExpectedOutput(path);
      } 
    } 
    if (testCase.getActualOutput() == null || testCase.getActualOutput().trim().length() == 0) {
      if (testCase.getInput().trim().startsWith(String.valueOf(source) + testCaseName)) {
        testCase.setActualOutput(String.valueOf(source) + testCaseName + File.separator + testCaseName + "Actual");
      } else {
        testCase.setActualOutput(String.valueOf(source) + testCaseName + "Actual" + "." + testCase.getTargetFormat().trim());
      } 
    } else {
      file = new File(testCase.getInput().trim());
      if (!file.isAbsolute()) {
        String path = String.valueOf(source) + testCase.getActualOutput().trim();
        testCase.setActualOutput(path);
      } 
    } 
    if (testCase.getSecurityInfo() == null || testCase.getSecurityInfo().trim().length() == 0) {
      if (testCase.getInput().trim().startsWith(String.valueOf(source) + testCaseName)) {
        testCase.setSecurityInfo(String.valueOf(source) + testCaseName + File.separator + testCaseName + "Security.properties");
      } else {
        testCase.setSecurityInfo(String.valueOf(source) + testCaseName + "Security.properties");
      } 
    } else {
      file = new File(testCase.getSecurityInfo().trim());
      if (!file.isAbsolute()) {
        String path = String.valueOf(source) + testCase.getSecurityInfo().trim();
        testCase.setSecurityInfo(path);
      } 
    } 
    //Added for Header details -- NML
    if (testCase.getHeaderInfo() == null || testCase.getHeaderInfo().trim().length() == 0) {
        if (testCase.getInput().trim().startsWith(String.valueOf(source) + testCaseName)) {
          testCase.setHeaderInfo(String.valueOf(source) + testCaseName + File.separator + testCaseName + "Header.properties");
        } else {
          testCase.setHeaderInfo(String.valueOf(source) + testCaseName + "Header.properties");
        } 
      } else {
        file = new File(testCase.getHeaderInfo().trim());
        if (!file.isAbsolute()) {
          String path = String.valueOf(source) + testCase.getHeaderInfo().trim();
          testCase.setHeaderInfo(path);
        } 
      }
    if (testCase.getDigitalSignatureInfo() == null || testCase.getDigitalSignatureInfo().trim().length() == 0) {
      if (testCase.getInput().trim().startsWith(String.valueOf(source) + testCaseName)) {
        testCase.setDigitalSignatureInfo(String.valueOf(source) + testCaseName + File.separator + testCaseName + "DigitalSignature.properties");
      } else {
        testCase.setDigitalSignatureInfo(String.valueOf(source) + testCaseName + "DigitalSignature.properties");
      } 
    } else {
      file = new File(testCase.getDigitalSignatureInfo().trim());
      if (!file.isAbsolute()) {
        String path = String.valueOf(source) + testCase.getDigitalSignatureInfo().trim();
        testCase.setDigitalSignatureInfo(path);
      } 
    } 
    if (testCase.getSourceInfo() == null || testCase.getSourceInfo().trim().length() == 0) {
      if (testCase.getInput().trim().startsWith(String.valueOf(source) + testCaseName)) {
        testCase.setSourceInfo(String.valueOf(source) + testCaseName + File.separator + testCaseName + "Source.properties");
      } else {
        testCase.setSourceInfo(String.valueOf(source) + testCaseName + "Source.properties");
      } 
    } else {
      file = new File(testCase.getSourceInfo().trim());
      if (!file.isAbsolute()) {
        String path = String.valueOf(source) + testCase.getSourceInfo().trim();
        testCase.setSourceInfo(path);
      } 
    } 
    if (testCase.getTargetInfo() == null || testCase.getTargetInfo().trim().length() == 0) {
      if (testCase.getInput().trim().startsWith(String.valueOf(source) + testCaseName)) {
        testCase.setTargetInfo(String.valueOf(source) + testCaseName + File.separator + testCaseName + "Target.properties");
      } else {
        testCase.setTargetInfo(String.valueOf(source) + testCaseName + "Target.properties");
      } 
    } else {
      file = new File(testCase.getTargetInfo().trim());
      if (!file.isAbsolute()) {
        String path = String.valueOf(source) + testCase.getTargetInfo().trim();
        testCase.setTargetInfo(path);
      } 
    } 
    if (testCase.getTargetProtocol() == null || testCase.getTargetProtocol().trim().length() == 0)
      testCase.setTargetProtocol(testCase.getSourceProtocol()); 
  }
  
  public TestConfDTO loadTestConf(String propfileLocation) throws Exception {
    TestConfDTO confDTO = new TestConfDTO();
    FileInputStream propis = null;
    Properties configProperties = new Properties();
    try {
      File file = new File(propfileLocation);
      if (file.exists()) {
        propis = new FileInputStream(propfileLocation);
        configProperties.load(propis);
        confDTO.setValueFromProperties(configProperties);
      } 
      return confDTO;
    } finally {
      if (propis != null)
        propis.close(); 
    } 
  }
  
  public void createXMLReport(List<String> testCaseXMLReports, String source, int noOFFailures, String time) {
    PrintWriter xmlWriter = null;
    try {
      xmlWriter = new PrintWriter(String.valueOf(source) + "Report.xml", "UTF-8");
      xmlWriter.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
      xmlWriter.println("<testsuite id=\"serviceValidator\" name=\"testsuite\" tests=\"" + testCaseXMLReports.size() + "\" failures=\"" + noOFFailures + "\" time=\"" + time + "\">");
      for (String report : testCaseXMLReports)
        xmlWriter.println(report); 
      xmlWriter.println("</testsuite>");
    } catch (Exception e) {
      log.error("Error writing XML file");
      System.out.println("Error writing XML file");
    } finally {
      if (xmlWriter != null)
        xmlWriter.close(); 
    } 
  }
}
