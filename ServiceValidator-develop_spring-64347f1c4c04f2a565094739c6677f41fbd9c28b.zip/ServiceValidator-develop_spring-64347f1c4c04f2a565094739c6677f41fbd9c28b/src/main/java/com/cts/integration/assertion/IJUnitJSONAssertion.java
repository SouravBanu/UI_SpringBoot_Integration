package com.cts.integration.assertion;

import java.util.List;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;

public class IJUnitJSONAssertion implements IJunitAssertion {
  static Logger log = Logger.getLogger(IJUnitJSONAssertion.class.getName());
  
  public void assertEquals(Object expected, Object actual, List<String> ignoredList) throws Exception {
    String expectedStr = (String)expected;
    String actualStr = (String)actual;
    if (expectedStr.trim().startsWith("[")) {
      JSONArray expectedArr = new JSONArray(expectedStr);
      JSONArray actualArr = new JSONArray(actualStr);
      maskWhiteList(actualArr, expectedArr, ignoredList);
      JSONAssert.assertEquals(expectedArr, actualArr, true);
    } else {
      JSONObject expectedObj = new JSONObject(expectedStr);
      JSONObject actualObj = new JSONObject(actualStr);
      maskWhiteList(actualObj, expectedObj, ignoredList);
      JSONAssert.assertEquals(expectedObj, actualObj, true);
    } 
  }
  
  public void maskWhiteList(Object actual, Object expected, List<String> whiteList) {
    for (String path : whiteList) {
      log.info(" Masking whitelisted elemetns with 1 to skip comparison " + path);
      setValueToPath(expected, path, "1");
      setValueToPath(actual, path, "1");
    } 
  }
  
  public void setValueToPath(Object json, String path, String value) {
    StringTokenizer st = new StringTokenizer(path.trim(), ".");
    Object childObject = json;
    boolean loopError = false;
    try {
      int noOfTokens = st.countTokens();
      for (int i = 1; i < noOfTokens; i++) {
        Object tempObject = null;
        try {
          if (childObject instanceof JSONObject) {
            tempObject = ((JSONObject)childObject).get((String)st.nextElement());
          } else {
            tempObject = ((JSONArray)childObject).get(Integer.parseInt((String)st.nextElement()));
          } 
          childObject = tempObject;
        } catch (Exception JSNexcelption) {
          loopError = true;
          break;
        } 
      } 
      if (!loopError && 
        childObject instanceof JSONObject)
        ((JSONObject)childObject).put((String)st.nextElement(), value); 
    } catch (JSONException je) {
      je.printStackTrace();
    } 
  }
}
