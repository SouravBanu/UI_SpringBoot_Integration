package com.cts.integration.unitTest;

import com.cts.integration.dto.RequestDTO;
import com.cts.integration.unitTest.client.GetJSONClient;
import com.cts.integration.unitTest.client.JSON2WaySSLClient;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.Properties;
import java.util.Set;
import junit.framework.TestCase;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;

public class PostJSONUTC extends TestCase {
  Properties wsProp = new Properties();
  
  static Logger log = Logger.getLogger(PostJSONUTC.class.getName());
  
  public void test() throws FileNotFoundException, Exception {
    InputStream wsInput = null;
    FileInputStream propInputStream = null;
    log.debug("testXMLHttpWs()");
    try {
      String source = System.getProperty("RootSource");
      if (source == null || source.trim().length() == 0)
        source = String.valueOf(System.getProperty("user.dir")) + File.separator; 
      wsInput = new FileInputStream(String.valueOf(source) + "postJSON" + File.separator + "url.properties");
      this.wsProp.load(wsInput);
      Set<Object> keys = this.wsProp.keySet();
      for (Object k : keys) {
        String testName = (String)k;
        String jsonURL = this.wsProp.getProperty(testName);
        String requestJSONPath = String.valueOf(source) + "postJSON" + File.separator + testName + File.separator + testName + "Input.json";
        String expectedJSONPath = String.valueOf(source) + "postJSON" + File.separator + testName + File.separator + testName + "Expected.json";
        String actualJSONPath = String.valueOf(source) + "postJSON" + File.separator + testName + File.separator + testName + "Actual.json";
        File securityPropertyfile = new File(String.valueOf(source) + "xmlHttpWebservice" + File.separator + testName + File.separator + testName + "Security.properties");
        RequestDTO request = new RequestDTO();
        request.setRequestPath(requestJSONPath);
        request.setServiceURL(jsonURL);
        request.setMethod("POST");
        if (securityPropertyfile.exists()) {
          request.setSecured(true);
          Properties securityProp = new Properties();
          propInputStream = new FileInputStream(securityPropertyfile);
          securityProp.load(propInputStream);
          request.setSecurityType(securityProp.getProperty("type"));
          if ("CERT".equalsIgnoreCase(securityProp.getProperty("type"))) {
            request.setCertPath(String.valueOf(source) + "xmlHttpWebservice" + File.separator + testName + File.separator + securityProp.getProperty("CERTNAME"));
          } else {
            request.setUserName(securityProp.getProperty("USERNAME"));
            request.setPassword(securityProp.getProperty("PASSWORD"));
          } 
        } 
        Object actaulJSON = JSON2WaySSLClient.invokeService(request);
        File responseFile = new File(actualJSONPath);
        responseFile.createNewFile();
        OutputStreamWriter oSW = new OutputStreamWriter(
            new FileOutputStream(responseFile));
        oSW.write(actaulJSON.toString());
        oSW.flush();
        oSW.close();
        Reader expectedJSONReader = new InputStreamReader(new FileInputStream(expectedJSONPath));
        String expectedJSONstr = GetJSONClient.readAll(expectedJSONReader);
        JSONObject expectedJSONObject = null;
        JSONArray expectedJSONArray = null;
        if (expectedJSONstr.trim().startsWith("[")) {
          expectedJSONArray = new JSONArray(expectedJSONstr);
        } else {
          expectedJSONObject = new JSONObject(expectedJSONstr);
        } 
        log.debug("Executing Testcase :" + testName);
        if (actaulJSON instanceof JSONArray) {
          JSONAssert.assertEquals(expectedJSONArray, (JSONArray)actaulJSON, false);
          continue;
        } 
        JSONAssert.assertEquals(expectedJSONObject, (JSONObject)actaulJSON, false);
      } 
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (wsInput != null)
        wsInput.close(); 
      if (propInputStream != null)
        propInputStream.close(); 
    } 
  }
}
