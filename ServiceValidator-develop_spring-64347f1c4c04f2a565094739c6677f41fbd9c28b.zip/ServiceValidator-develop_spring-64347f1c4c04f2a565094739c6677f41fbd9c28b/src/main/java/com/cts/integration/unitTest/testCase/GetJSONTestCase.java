package com.cts.integration.unitTest.testCase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.Properties;

import junit.framework.TestCase;

import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;

import com.cts.integration.dto.IJunitTestCase;
import com.cts.integration.dto.RequestDTO;
import com.cts.integration.unitTest.client.GetJSONClient;
import com.cts.integration.unitTest.client.JSON2WaySSLClient;
import com.cts.integration.unitTest.client.XML2WaySSLHttpClient;

public class GetJSONTestCase extends TestCase {
	
	/*public static String testName =null;
	public static String source =null;
	public static String jsonURL =null;
	public static String asisURL =null;*/
	
	public void test() throws FileNotFoundException, Exception{
		FileInputStream propInputStream = null;
		FileOutputStream actualFOS = null;
	    OutputStreamWriter actualOSW = null;
	    FileOutputStream expectedFOS = null;
	    OutputStreamWriter expectedOSW = null;
	    Reader expectedJSONReader = null;
	    
		try{
						
			
	       
	            
	            //final String requestJSONPath = source+"getJSON"+File.separator+testName+File.separator+testName+"Input.json";      
	  	        String expectedJSONPath = IJunitTestCase.getTestCase().getExpectedOutput();;		    
	  	        String actualJSONPath = IJunitTestCase.getTestCase().getActualOutput();    
	  	        File securityPropertyfile = new File(IJunitTestCase.getTestCase().getSecurityInfo());
	  	        Properties securityProp = new Properties();
	  	        RequestDTO request = new RequestDTO();
	  	      
	  	        
		        request.setServiceURL(IJunitTestCase.getTestCase().getEndpoint().trim());
		        request.setMethod("GET");
		        if(securityPropertyfile.exists()){
		        	request.setSecured(true);
		        	securityProp = new Properties();
		        	propInputStream = new FileInputStream(securityPropertyfile);
		        	securityProp.load(propInputStream);
		        	request.setSecurityType(securityProp.getProperty("type"));
		        	if(RequestDTO.SECURITY_TYPE_CERT.equalsIgnoreCase(securityProp.getProperty("type"))){
		        		String cert = securityProp.getProperty("CERTNAME");
		  	        	File certFile = new File(cert);
		  	        	String certPath = null;
		  	        	if(!certFile.isAbsolute()){
			  	        	if(IJunitTestCase.getTestCase().getInput().trim().startsWith(IJunitTestCase.getTestCase().getSource()+IJunitTestCase.getTestCase().getTestCase())){
			  	        		certPath = IJunitTestCase.getTestCase().getSource()+IJunitTestCase.getTestCase().getTestCase().trim()+File.separator+cert;
			  	  			}else{
			  	  				certPath = IJunitTestCase.getTestCase().getSource()+cert;
			  	  			}
		  	        	}else{
		  	        		certPath = cert;
		  	        	}
	  	        		request.setCertPath(certPath);
		        		request.setKeystoreType(securityProp.getProperty("KEYSTORETYPE"));
	  	        		request.setKeystorePass(securityProp.getProperty("KEYSTOREPASSWORD"));
		        	}else{
		        		request.setUserName(securityProp.getProperty("USERNAME"));
		        		request.setPassword(securityProp.getProperty("PASSWORD"));
		        	}
		        }
	  	        
	  	        //Object actaulJSON =  GetJSONClient.readJsonFromUrl(jsonURL);
	  	        Object actaulJSON =  JSON2WaySSLClient.invokeService(request);
	  	        
	  	      // Store the response in the disk    
	  	      File responseFile = new File(actualJSONPath);    
		      responseFile.createNewFile();    
		      actualFOS = new FileOutputStream(responseFile);
		      actualOSW = new OutputStreamWriter(actualFOS); 
		      actualOSW.write(actaulJSON.toString());	    
		      actualOSW.flush();    
		      actualFOS.flush();
		      String asisURL = IJunitTestCase.getTestCase().getLegacyEndPont().trim();
		      if(asisURL == null || asisURL.trim().length() ==0){
		    	  expectedJSONReader = new InputStreamReader(new FileInputStream(expectedJSONPath));
		      }
		      else{
		    	  request.setServiceURL(asisURL);
		    	  if(securityPropertyfile.exists() 
		    			  && RequestDTO.SECURITY_TYPE_BASIC.equalsIgnoreCase(securityProp.getProperty("type")) 
		    			  && securityProp.getProperty("LEGACYUSERNAME")!=null 
		    			  && securityProp.getProperty("LEGACYUSERNAME").trim().length()>0){
		    		  request.setUserName(securityProp.getProperty("LEGACYUSERNAME"));
		    		  request.setPassword(securityProp.getProperty("LEGACYPASSWORD"));
		    	  }
		    	  Object asisResponse = JSON2WaySSLClient.invokeService(request);
		    	  
		    	  File expectedFile = new File(expectedJSONPath);    
		    	  expectedFile.createNewFile(); 
			      expectedFOS = new FileOutputStream(expectedFile);
			      expectedOSW = new OutputStreamWriter(expectedFOS); 
			      expectedOSW.write(asisResponse.toString());	    
			      expectedOSW.flush();
			      expectedFOS.flush();
			      expectedJSONReader = new InputStreamReader(new FileInputStream(expectedJSONPath));
		      }
	  	        
	  	       
	  	        String expectedJSONstr =GetJSONClient.readAll(expectedJSONReader);
	  	        //String expectedJSONVal = expectedJSONstr.replace("[", "").replace("]", "");
		  	    JSONObject expectedJSONObject =null;
		  	    JSONArray expectedJSONArray = null;
	  	        if(expectedJSONstr.trim().startsWith("[")){
	  	        	expectedJSONArray = new JSONArray(expectedJSONstr);
	  	        	
			      }else{
			    	  expectedJSONObject = new JSONObject(expectedJSONstr);
			      }
	  	        
	  	        //System.out.println("actual: "+actaulJSON.toString()); 
	  	        //System.out.println("expected: "+expectedJSONstr.toString());
	  	        //assertEquals(expectedJSONObject, actaulJSON);
	  	        //JSONAssert.assertEquals(expectedJSONObject, actaulJSON, false);
	  	        if(actaulJSON instanceof JSONArray){
	  	        	//System.out.println(" comparing JSONArray for "+testName);
	  	        	JSONAssert.assertEquals(expectedJSONArray, (JSONArray)actaulJSON, false);
	  	        	
	  	        }else{
	  	        	//System.out.println(" comparing JSONObjects for "+testName);
	  	        	JSONAssert.assertEquals(expectedJSONObject, (JSONObject)actaulJSON, true);
	  	        }

	       
	        
		 }catch(Exception e){
		    	
	        	//writer.println(e.getMessage());
	    	   	e.printStackTrace();
	        	throw e;
		}finally{
			if(propInputStream!=null){
				propInputStream.close();
			}
			if(actualOSW != null){
				//actualOSW.flush();    
			    actualOSW.close();  
			}
			if(actualFOS != null){
				//actualFOS.flush();
				actualFOS.close();
			}
			if(expectedOSW != null){
				//actualOSW.flush();    
				expectedOSW.close();  
			}
			if(expectedFOS != null){
				//actualFOS.flush();
				expectedFOS.close();
			}
			if(expectedJSONReader != null){
				//actualFOS.flush();
				expectedJSONReader.close();
			}
		}
	}
}
