package com.cts.integration.dto;

public class ExcelColumnConstants {
  public static final int TESTCASE = 1;
  
  public static final int DESCRPTION = 2;
  
  public static final int PATTERN = 3;
  
  public static final int SOURCEPROTOCOL = 4;
  
  public static final int SOURCEFORMAT = 5;
  
  public static final int TARGETPROTOCOL = 6;
  
  public static final int TARGETFORMAT = 7;
  
  public static final int SECURITYINFO = 8;
  
  public static final int ENDPOINT = 9;
  
  public static final int LEGACYENDPOINT = 10;
  
  public static final int SOURCEINFO = 11;
  
  public static final int TARGETINFO = 12;
  
  public static final int INPUT = 13;
  
  public static final int EXPECTEDOUTPUT = 14;
  
  public static final int ACTUALOUTPUT = 15;
  
  public static final int DIGITALSIGNATUREINFO = 16;
  
  public static final int IGNORELIST = 17;
  
  public static final int ROWNUM = 0;
  
  public static final int ISACTIVE = 18;
  
  public static final String DEFAULT_SHEET_NAME = "TestCases";
  
  //Added for headerdetails -- NML
  public static final int HEADERINFO = 19;
}
