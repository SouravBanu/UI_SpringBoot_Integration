package com.cts.integration.unitTest.client;

public class HelloProducerConsumer {}
