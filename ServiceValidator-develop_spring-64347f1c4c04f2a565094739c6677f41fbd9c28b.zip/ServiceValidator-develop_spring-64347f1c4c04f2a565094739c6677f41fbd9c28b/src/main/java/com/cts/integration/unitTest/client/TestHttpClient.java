package com.cts.integration.unitTest.client;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;

public class TestHttpClient {
  public static String invokeWebService(String webServiceURL, String requestXMLPath) throws FileNotFoundException, Exception {
    PostMethod post = null;
    HttpClient client = new HttpClient();
    BufferedReader bufferedReader = null;
    FileReader fr = null;
    try {
      StringBuffer requestFileContents = new StringBuffer();
      fr = new FileReader(requestXMLPath);
      bufferedReader = new BufferedReader(fr);
      String line = null;
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      webServiceURL.trim().startsWith("https");
      post = new PostMethod(webServiceURL);
      post.setRequestHeader("Accept", "application/soap+xml,application/dime,multipart/related,text/*");
      post.setRequestHeader("SOAPAction", "");
      StringRequestEntity stringRequestEntity = new StringRequestEntity(requestFileContents
          .toString(), "text/xml", "utf-8");
      post.setRequestEntity((RequestEntity)stringRequestEntity);
      int result = client.executeMethod((HttpMethod)post);
      String response = post.getResponseBodyAsString();
      return response;
    } finally {
      if (post != null)
        post.releaseConnection(); 
      if (fr != null)
        fr.close(); 
      if (bufferedReader != null)
        bufferedReader.close(); 
    } 
  }
}
