package com.cts.integration.util;

import com.cts.integration.dto.DigitalSignatureDTO;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.xml.security.Init;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.XMLUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class AdvancedDigitalSignatureUtility {
  static {
    Init.init();
  }
  
  public static String digitallySign(DigitalSignatureDTO signDTO) throws Exception {
    FileInputStream fis = null;
    FileOutputStream f = null;
    try {
      File signedFile = new File(signDTO.getSignedFile());
      Element element = null;
      String BaseURI = signedFile.toURI().toURL().toString();
      File sourceFile = new File(signDTO.getInputFile());
      KeyStore ks = KeyStore.getInstance(signDTO.getKeyStoreType());
      fis = new FileInputStream(signDTO.getKeystoreFileLocation());
      ks.load(fis, signDTO.getKeyStorePassword().toCharArray());
      PrivateKey privateKey = 
        (PrivateKey)ks.getKey(signDTO.getKeyAlias(), signDTO.getKeyPassword().toCharArray());
      DocumentBuilderFactory dbf = 
        DocumentBuilderFactory.newInstance();
      dbf.setNamespaceAware(true);
      DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
      Document doc = dBuilder.parse(sourceFile);
      XMLSignature sig = 
        new XMLSignature(doc, BaseURI, "http://www.w3.org/2000/09/xmldsig#rsa-sha1");
      element = doc.getDocumentElement();
      element.normalize();
      element.getElementsByTagName("soapenv:Header").item(0).appendChild(sig.getElement());
      Transforms transforms = new Transforms(doc);
      transforms.addTransform("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
      sig.addDocument("", transforms, "http://www.w3.org/2000/09/xmldsig#sha1");
      X509Certificate cert1 = (X509Certificate)ks.getCertificate(signDTO.getKeyAlias());
      sig.addKeyInfo(cert1);
      sig.addKeyInfo(cert1.getPublicKey());
      System.out.println("Start signing");
      sig.sign(privateKey);
      System.out.println("Finished signing");
      try {
        f = new FileOutputStream(signedFile);
        XMLUtils.outputDOMc14nWithComments(doc, f);
      } finally {
        if (f != null)
          f.close(); 
      } 
      System.out.println("Wrote signature to " + BaseURI);
      return FileUtil.readFileAsString(signDTO.getSignedFile());
    } finally {
      if (fis != null)
        fis.close(); 
    } 
  }
}
