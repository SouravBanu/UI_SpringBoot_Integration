package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;

public interface IJunitClient {
  void put(ComplexRequestDTO paramComplexRequestDTO) throws Exception;
  
  void get(ComplexRequestDTO paramComplexRequestDTO) throws Exception;
  
  void cleanResponseContainer(ComplexRequestDTO paramComplexRequestDTO) throws Exception;
  
  void synchCall(ComplexRequestDTO paramComplexRequestDTO) throws Exception;
}
