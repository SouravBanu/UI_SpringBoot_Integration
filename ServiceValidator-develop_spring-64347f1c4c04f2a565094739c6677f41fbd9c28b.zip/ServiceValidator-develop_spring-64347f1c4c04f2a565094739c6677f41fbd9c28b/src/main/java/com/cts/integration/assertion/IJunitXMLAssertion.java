package com.cts.integration.assertion;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.XMLAssert;
import org.custommonkey.xmlunit.XMLUnit;

public class IJunitXMLAssertion implements IJunitAssertion {
  public void assertEquals(Object expected, Object actual, List<String> ignoredList) throws Exception {
    InputStream expectedis = null;
    Reader expectedReader = null;
    InputStream actualis = null;
    Reader actualReader = null;
    try {
      String expectedStr = (String)expected;
      expectedis = new ByteArrayInputStream(expectedStr.getBytes());
      expectedReader = new InputStreamReader(expectedis);
      String actualStr = (String)actual;
      actualis = new ByteArrayInputStream(actualStr.getBytes());
      actualReader = new InputStreamReader(actualis);
      XMLUnit.setIgnoreWhitespace(true);
      Diff xmlDiff = new Diff(expectedReader, actualReader);
      xmlDiff.overrideDifferenceListener(new IgnoreElementDifferenceListener(ignoredList));
      XMLAssert.assertXMLEqual(xmlDiff, true);
    } finally {
      if (expectedis != null)
        expectedis.close(); 
      if (expectedReader != null)
        expectedReader.close(); 
      if (actualis != null)
        actualis.close(); 
      if (actualReader != null)
        actualReader.close(); 
    } 
  }
}
