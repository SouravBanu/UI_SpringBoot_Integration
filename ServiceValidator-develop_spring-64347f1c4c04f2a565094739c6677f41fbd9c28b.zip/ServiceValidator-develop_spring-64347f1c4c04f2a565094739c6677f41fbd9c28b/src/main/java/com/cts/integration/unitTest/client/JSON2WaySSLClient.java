package com.cts.integration.unitTest.client;

import com.cts.integration.dto.RequestDTO;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLContext;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JSON2WaySSLClient {
  public static Object invokeService(RequestDTO request) throws FileNotFoundException, IOException, KeyStoreException, CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyManagementException, JSONException {
    BufferedReader bufferedReader = null;
    FileReader fr = null;
    FileInputStream kis = null;
    HttpClient httpClient = null;
    try {
      CloseableHttpClient closeableHttpClient;
      if (request.isSecured() && "CERT".equalsIgnoreCase(request.getSecurityType())) {
        KeyStore keyStore = KeyStore.getInstance(request.getKeystoreType());
        kis = new FileInputStream(request.getCertPath());
        keyStore.load(kis, "changeit".toCharArray());
        SSLContext sslContext = SSLContexts.custom().loadKeyMaterial(keyStore, request.getKeystorePass().toCharArray()).build();
        closeableHttpClient = HttpClients.custom().setSslcontext(sslContext).build();
      } else if (request.isSecured() && "BASIC".equalsIgnoreCase(request.getSecurityType())) {
        BasicCredentialsProvider basicCredentialsProvider = new BasicCredentialsProvider();
        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(request.getUserName(), request.getPassword());
        basicCredentialsProvider.setCredentials(AuthScope.ANY, (Credentials)credentials);
        closeableHttpClient = HttpClientBuilder.create().setDefaultCredentialsProvider((CredentialsProvider)basicCredentialsProvider).build();
      } else {
        closeableHttpClient = HttpClientBuilder.create().build();
      } 
      if ("GET".equalsIgnoreCase(request.getMethod())) {
        HttpGet httpget = new HttpGet(request.getServiceURL());
        httpget.setHeader("content-type", "application/json");
        httpget.setHeader("Accept", "application/json");
        HttpResponse httpResponse1 = closeableHttpClient.execute((HttpUriRequest)httpget);
        String str = EntityUtils.toString(httpResponse1.getEntity());
        JSONObject jSONObject = null;
        JSONArray jSONArray = null;
        if (str.trim().startsWith("[")) {
          jSONArray = new JSONArray(str);
          return jSONArray;
        } 
        jSONObject = new JSONObject(str);
        return jSONObject;
      } 
      StringBuffer requestFileContents = new StringBuffer();
      fr = new FileReader(request.getRequestPath());
      bufferedReader = new BufferedReader(fr);
      String line = null;
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      HttpPost httppost = new HttpPost(request.getServiceURL());
      httppost.setHeader("content-type", "application/json");
      httppost.setHeader("Accept", "application/json");
      StringEntity se = new StringEntity(requestFileContents.toString());
      httppost.setEntity((HttpEntity)se);
      HttpResponse httpResponse = closeableHttpClient.execute((HttpUriRequest)httppost);
      String response = EntityUtils.toString(httpResponse.getEntity());
      JSONObject jsonObj = null;
      JSONArray jarray = null;
      if (response.trim().startsWith("[")) {
        jarray = new JSONArray(response);
        return jarray;
      } 
      jsonObj = new JSONObject(response);
      return jsonObj;
    } finally {
      if (fr != null)
        fr.close(); 
      if (bufferedReader != null)
        bufferedReader.close(); 
      if (kis != null)
        kis.close(); 
    } 
  }
  
  public static Object invokeService(String jsonURL, String requestJSONPath, String source, String method) throws FileNotFoundException, IOException, KeyStoreException, CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyManagementException, JSONException {
    BufferedReader bufferedReader = null;
    FileReader fr = null;
    FileInputStream kis = null;
    try {
      KeyStore keyStore = KeyStore.getInstance("JKS");
      kis = new FileInputStream(String.valueOf(source) + File.separator + "clientCertAndKey" + File.separator + "clientks.jks");
      keyStore.load(kis, "changeit".toCharArray());
      SSLContext sslContext = SSLContexts.custom().loadKeyMaterial(keyStore, "changeit".toCharArray()).build();
      CloseableHttpClient closeableHttpClient = HttpClients.custom().setSslcontext(sslContext).build();
      if ("GET".equalsIgnoreCase(method)) {
        HttpGet httpget = new HttpGet(jsonURL);
        httpget.setHeader("content-type", "application/json");
        httpget.setHeader("Accept", "application/json");
        HttpResponse httpResponse1 = closeableHttpClient.execute((HttpUriRequest)httpget);
        String str = EntityUtils.toString(httpResponse1.getEntity());
        JSONObject jSONObject = null;
        JSONArray jSONArray = null;
        if (str.trim().startsWith("[")) {
          jSONArray = new JSONArray(str);
          return jSONArray;
        } 
        jSONObject = new JSONObject(str);
        return jSONObject;
      } 
      StringBuffer requestFileContents = new StringBuffer();
      fr = new FileReader(requestJSONPath);
      bufferedReader = new BufferedReader(fr);
      String line = null;
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      HttpPost httppost = new HttpPost(jsonURL);
      httppost.setHeader("content-type", "application/json");
      httppost.setHeader("Accept", "application/json");
      StringEntity se = new StringEntity(requestFileContents.toString());
      httppost.setEntity((HttpEntity)se);
      HttpResponse httpResponse = closeableHttpClient.execute((HttpUriRequest)httppost);
      String response = EntityUtils.toString(httpResponse.getEntity());
      JSONObject jsonObj = null;
      JSONArray jarray = null;
      if (response.trim().startsWith("[")) {
        jarray = new JSONArray(response);
        return jarray;
      } 
      jsonObj = new JSONObject(response);
      return jsonObj;
    } finally {
      if (fr != null)
        fr.close(); 
      if (bufferedReader != null)
        bufferedReader.close(); 
      if (kis != null)
        kis.close(); 
    } 
  }
}
