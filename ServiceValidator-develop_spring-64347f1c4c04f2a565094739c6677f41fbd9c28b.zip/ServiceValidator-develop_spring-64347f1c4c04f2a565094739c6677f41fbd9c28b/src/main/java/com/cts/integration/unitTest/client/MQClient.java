package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.MQRequestDTO;
import com.cts.integration.util.FileUtil;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import org.apache.log4j.Logger;

public class MQClient implements IJunitClient {
  static Logger log = Logger.getLogger(MQClient.class.getName());
  
  public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("MQClient -> PUT");
    log.debug(" setting env " + complexRequestDTO.getHost() + " " + complexRequestDTO.getPort() + " " + complexRequestDTO.getChannel());
    setMQEnvironment(complexRequestDTO.getHost(), complexRequestDTO.getPort(), complexRequestDTO.getChannel());
    complexRequestDTO.setMessageId(putMessage(complexRequestDTO.getQueueManagerName(), complexRequestDTO.getRequestQueueName(), complexRequestDTO.getReplyToQueueManager(), complexRequestDTO.getResponseQueueName(), complexRequestDTO.getMessage()));
    log.info("MQClient -> PUT Finished");
  }
  
  public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("MQClient -> GET");
    byte[] messageId = (byte[])null;
    byte[] correlationId = (byte[])null;
    if ("CORRELATIONID".equalsIgnoreCase(complexRequestDTO.getCorrelationType())) {
      correlationId = complexRequestDTO.getMessageId();
    } else if ("MESSAGEID".equalsIgnoreCase(complexRequestDTO.getCorrelationType())) {
      messageId = complexRequestDTO.getMessageId();
    } 
    log.debug("Getting message by " + complexRequestDTO.getCorrelationType());
    setMQEnvironment(complexRequestDTO.getReplyHost(), complexRequestDTO.getReplyPort(), complexRequestDTO.getReplyChannel());
    MQMessage message = getMessage(complexRequestDTO.getReplyToQueueManager(), complexRequestDTO.getResponseQueueName(), complexRequestDTO.getWaitInterval(), correlationId, messageId);
    complexRequestDTO.setResponse(message.readStringOfCharLength(message.getMessageLength()));
    FileUtil.writeToFile(complexRequestDTO.getTestOutputFileLocation(), complexRequestDTO.getResponse());
  }
  
  public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO) throws Exception {
    if ("NONE".equalsIgnoreCase(complexRequestDTO.getCorrelationType())) {
      setMQEnvironment(complexRequestDTO.getReplyHost(), complexRequestDTO.getReplyPort(), complexRequestDTO.getReplyChannel());
      clearMQ(complexRequestDTO.getReplyToQueueManager(), complexRequestDTO.getResponseQueueName());
      log.debug("Target Cleaned");
    } 
  }
  
  public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Synch Call for MQClient");
    cleanResponseContainer(complexRequestDTO);
    put(complexRequestDTO);
    get(complexRequestDTO);
  }
  
  public static void main(String[] a) throws Exception {}
  
  public static String invoke2WayMQService(MQRequestDTO mqRequestDTO) throws Exception {
    String queueManagerName = mqRequestDTO.getQueueManagerName();
    String replyQueueManagerName = mqRequestDTO.getReplyToQueueManager();
    String responseQueueName = mqRequestDTO.getResponseQueueName();
    String requestQueueName = mqRequestDTO.getRequestQueueName();
    String requestInfo = mqRequestDTO.getMessage();
    String correlationType = mqRequestDTO.getCorrelationType();
    MQMessage responseMessage = null;
    int waitInterval = mqRequestDTO.getWaitInterval();
    if ("NONE".equalsIgnoreCase(correlationType)) {
      MQEnvironment.hostname = mqRequestDTO.getReplyHost();
      MQEnvironment.port = mqRequestDTO.getReplyPort();
      MQEnvironment.channel = mqRequestDTO.getReplyChannel();
      clearMQ(replyQueueManagerName, responseQueueName);
    } 
    MQEnvironment.hostname = mqRequestDTO.getHost();
    MQEnvironment.port = mqRequestDTO.getPort();
    MQEnvironment.channel = mqRequestDTO.getChannel();
    byte[] messageId = putMessage(queueManagerName, requestQueueName, replyQueueManagerName, responseQueueName, requestInfo);
    MQEnvironment.hostname = mqRequestDTO.getReplyHost();
    MQEnvironment.port = mqRequestDTO.getReplyPort();
    MQEnvironment.channel = mqRequestDTO.getReplyChannel();
    if ("CORRELATIONID".equalsIgnoreCase(correlationType)) {
      responseMessage = getMessage(replyQueueManagerName, responseQueueName, waitInterval, messageId, null);
    } else if ("MESSAGEID".equalsIgnoreCase(correlationType)) {
      responseMessage = getMessage(replyQueueManagerName, responseQueueName, waitInterval, null, messageId);
    } else {
      responseMessage = getMessage(replyQueueManagerName, responseQueueName, waitInterval, null, null);
    } 
    String msgtext = responseMessage.readStringOfCharLength(responseMessage.getMessageLength());
    return msgtext;
  }
  
  public static byte[] putMessage(String queueManagerName, String queueName, String replytoQueueManager, String replyQueue, String message) throws Exception {
    MQQueueManager queueManager = null;
    MQQueue requestQueue = null;
    try {
      log.debug(" Putting date in " + queueName + " " + queueManagerName);
      queueManager = new MQQueueManager(queueManagerName);
      MQMessage requestMessage = new MQMessage();
      if (replyQueue != null && replyQueue.trim().length() != 0) {
        requestQueue = queueManager.accessQueue(queueName, 16);
        requestMessage.replyToQueueManagerName = replytoQueueManager;
        requestMessage.replyToQueueName = replyQueue;
        requestMessage.messageType = 1;
      } else {
        requestQueue = queueManager.accessQueue(queueName, 17);
        requestMessage.messageType = 8;
      } 
      requestMessage.writeString(message);
      MQPutMessageOptions pmo = new MQPutMessageOptions();
      requestQueue.put(requestMessage, pmo);
      return requestMessage.messageId;
    } finally {
      if (requestQueue != null)
        requestQueue.close(); 
      if (queueManager != null)
        queueManager.disconnect(); 
    } 
  }
  
  public static MQMessage getMessage(String queueManagerName, String queueName, int waitInterval, byte[] correlationId, byte[] messageId) throws Exception {
    MQQueueManager queueManager = null;
    MQQueue responseQueue = null;
    try {
      queueManager = new MQQueueManager(queueManagerName);
      responseQueue = queueManager.accessQueue(queueName, 4);
      MQMessage responseMessage = new MQMessage();
      MQGetMessageOptions gmo = new MQGetMessageOptions();
      if (correlationId != null)
        responseMessage.correlationId = correlationId; 
      if (messageId != null)
        responseMessage.messageId = messageId; 
      gmo.waitInterval = waitInterval;
      gmo.options = 1;
      responseQueue.get(responseMessage, gmo);
      return responseMessage;
    } finally {
      if (responseQueue != null)
        responseQueue.close(); 
      if (queueManager != null)
        queueManager.disconnect(); 
    } 
  }
  
  public static void browse(String queueManagerName, String queueName) throws Exception {
    int openOptions = 8202;
    MQQueueManager queueManager = null;
    MQQueue queue = null;
    MQMessage retrievemessage = new MQMessage();
    MQGetMessageOptions gmo = new MQGetMessageOptions();
    gmo.options = 17;
    gmo.matchOptions = 0;
    gmo.options = 1;
    try {
      queueManager = new MQQueueManager(queueManagerName);
      queue = queueManager.accessQueue(queueName, openOptions);
      boolean thereAreMessages = true;
      while (thereAreMessages) {
        try {
          System.out.println(" Retrieving ");
          queue.get(retrievemessage, gmo);
          System.out.println("Retrieved 1 message");
          gmo.options = 33;
        } catch (MQException e) {
          System.out.println("Gpt exception " + e.reasonCode);
          if (e.reasonCode == 2033) {
            System.out.println("no more message available or retrived");
          } else {
            throw e;
          } 
          thereAreMessages = false;
        } 
      } 
    } finally {
      if (queue != null)
        queue.close(); 
      if (queueManager != null)
        queueManager.close(); 
    } 
  }
  
  public static void clearMQ(String queueManagerName, String queueName) throws Exception {
    System.out.println(" A test case requires clearing the queue " + queueName + " of " + queueManagerName);
    boolean hasMessage = true;
    while (hasMessage) {
      try {
        getMessage(queueManagerName, queueName, 5000, null, null);
      } catch (MQException e) {
        if (e.reasonCode == 2033) {
          System.out.println("All prior messages cleared and hence got exception " + e.reasonCode + " Exception may be ignored");
        } else {
          System.out.println("Got exception " + e.reasonCode + " while attempting to clear queue ");
        } 
        hasMessage = false;
      } 
    } 
  }
  
  public static void setMQEnvironment(String host, int port, String channel) {
    MQEnvironment.hostname = host;
    MQEnvironment.port = port;
    MQEnvironment.channel = channel;
  }
}
