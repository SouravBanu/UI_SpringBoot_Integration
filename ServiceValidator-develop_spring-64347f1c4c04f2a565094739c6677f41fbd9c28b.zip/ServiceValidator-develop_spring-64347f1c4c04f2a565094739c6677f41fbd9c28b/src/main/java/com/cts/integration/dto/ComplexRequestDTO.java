package com.cts.integration.dto;

import com.cts.integration.util.FileUtil;
import java.util.Properties;

public class ComplexRequestDTO extends MQRequestDTO {
  String host;
  
  int port;
  
  String channel;
  
  String replyHost;
  
  int replyPort;
  
  String replyChannel;
  
  String queueManagerName;
  
  String replyToQueueManager;
  
  String requestQueueName;
  
  String responseQueueName;
  
  String message;
  
  String testInputFileLocation;
  
  String testOutputFileLocation;
  
  String correlationType;
  
  int waitInterval = 60000;
  
  byte[] messageId = null;
  
  String jmsMessageId;
  
  String jmsCorrelationId;
  
  String ftpUser;
  
  String ftpPassword;
  
  String localDirectory;
  
  String localFileName;
  
  String localPath;
  
  String ftpRemoteDelete = "FALSE";
  
  String remoteDirectory;
  
  String remoteFileName;
  
  String remotePath;
  
  String targetFormat;
  
  String sourceFormat;
  
  long fileftpWaitInterval = 60000L;
  
  long requestTimeInMS;
  
  long filePollInterval = 5000L;
  
  String response;
  
  String url;
  
  String httpMethod = "POST";
  
  String securityFile;
  
  //Added for headerdetails -- NML
  String headerFile;
  
  String digitalSignatureFile;
  
  String driverClass;
  
  String dbtype;
  
  String query;
  
  String cleanQuery;
  
  String dbURL;
  
  String dbUser;
  
  String dbPassword;
  
  String connectionFactory;
  
  String replyToConnectionFactory;
  
  String jmsConetxFactory = "com.sun.jndi.fscontext.RefFSContextFactory";
  
  String jmsProviderURL;
  
  String jmsByteMessageEncoding = "UTF-8";
  
  TestCaseDTO testCase;
  
  boolean isLegacy;
  
  
  
    
  public boolean isLegacy() {
    return this.isLegacy;
  }
  
  public void setLegacy(boolean isLegacy) {
    this.isLegacy = isLegacy;
  }
  
  public String getTestInputFileLocation() {
    return this.testInputFileLocation;
  }
  
  public void setTestInputFileLocation(String testInputFileLocation) {
    this.testInputFileLocation = testInputFileLocation;
  }
  
  public String getTestOutputFileLocation() {
    return this.testOutputFileLocation;
  }
  
  public void setTestOutputFileLocation(String testOutputFileLocation) {
    this.testOutputFileLocation = testOutputFileLocation;
  }
  
  public long getRequestTimeInMS() {
    return this.requestTimeInMS;
  }
  
  public void setRequestTimeInMS(long requestTimeInMS) {
    this.requestTimeInMS = requestTimeInMS;
  }
  
  public String getHost() {
    return this.host;
  }
  
  public void setHost(String host) {
    this.host = host;
  }
  
  public int getPort() {
    return this.port;
  }
  
  public void setPort(int port) {
    this.port = port;
  }
  
  public String getChannel() {
    return this.channel;
  }
  
  public void setChannel(String channel) {
    this.channel = channel;
  }
  
  public String getReplyHost() {
    return this.replyHost;
  }
  
  public void setReplyHost(String replyHost) {
    this.replyHost = replyHost;
  }
  
  public int getReplyPort() {
    return this.replyPort;
  }
  
  public void setReplyPort(int replyPort) {
    this.replyPort = replyPort;
  }
  
  public String getReplyChannel() {
    return this.replyChannel;
  }
  
  public void setReplyChannel(String replyChannel) {
    this.replyChannel = replyChannel;
  }
  
  public String getQueueManagerName() {
    return this.queueManagerName;
  }
  
  public void setQueueManagerName(String queueManagerName) {
    this.queueManagerName = queueManagerName;
  }
  
  public String getReplyToQueueManager() {
    return this.replyToQueueManager;
  }
  
  public void setReplyToQueueManager(String replyToQueueManager) {
    this.replyToQueueManager = replyToQueueManager;
  }
  
  public String getRequestQueueName() {
    return this.requestQueueName;
  }
  
  public void setRequestQueueName(String requestQueueName) {
    this.requestQueueName = requestQueueName;
  }
  
  public String getResponseQueueName() {
    return this.responseQueueName;
  }
  
  public void setResponseQueueName(String responseQueueName) {
    this.responseQueueName = responseQueueName;
  }
  
  public String getMessage() {
    return this.message;
  }
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public String getCorrelationType() {
    return this.correlationType;
  }
  
  public void setCorrelationType(String correlationType) {
    this.correlationType = correlationType;
  }
  
  public int getWaitInterval() {
    return this.waitInterval;
  }
  
  public void setWaitInterval(int waitInterval) {
    this.waitInterval = waitInterval;
  }
  
  public byte[] getMessageId() {
    return this.messageId;
  }
  
  public void setMessageId(byte[] messageId) {
    this.messageId = messageId;
  }
  
  public String getJmsMessageId() {
    return this.jmsMessageId;
  }
  
  public void setJmsMessageId(String jmsMessageId) {
    this.jmsMessageId = jmsMessageId;
  }
  
  public String getJmsCorrelationId() {
    return this.jmsCorrelationId;
  }
  
  public void setJmsCorrelationId(String jmsCorrelationId) {
    this.jmsCorrelationId = jmsCorrelationId;
  }
  
  public long getFileftpWaitInterval() {
    return this.fileftpWaitInterval;
  }
  
  public void setFileftpWaitInterval(long fileftpWaitInterval) {
    this.fileftpWaitInterval = fileftpWaitInterval;
  }
  
  public String getLocalDirectory() {
    return this.localDirectory;
  }
  
  public void setLocalDirectory(String localDirectory) {
    this.localDirectory = localDirectory;
  }
  
  public String getLocalFileName() {
    return this.localFileName;
  }
  
  public void setLocalFileName(String localFileName) {
    this.localFileName = localFileName;
  }
  
  public String getRemoteDirectory() {
    return this.remoteDirectory;
  }
  
  public void setRemoteDirectory(String remoteDirectory) {
    this.remoteDirectory = remoteDirectory;
  }
  
  public String getRemoteFileName() {
    return this.remoteFileName;
  }
  
  public void setRemoteFileName(String remoteFileName) {
    this.remoteFileName = remoteFileName;
  }
  
  public String getFtpRemoteDelete() {
    return this.ftpRemoteDelete;
  }
  
  public void setFtpRemoteDelete(String ftpRemoteDelete) {
    this.ftpRemoteDelete = ftpRemoteDelete;
  }
  
  public String getFtpUser() {
    return this.ftpUser;
  }
  
  public void setFtpUser(String ftpUser) {
    this.ftpUser = ftpUser;
  }
  
  public String getFtpPassword() {
    return this.ftpPassword;
  }
  
  public void setFtpPassword(String ftpPassword) {
    this.ftpPassword = ftpPassword;
  }
  
  public String getTargetFormat() {
    return this.targetFormat;
  }
  
  public void setTargetFormat(String format) {
    this.targetFormat = format;
  }
  
  public String getSourceFormat() {
    return this.sourceFormat;
  }
  
  public void setSourceFormat(String sourceFormat) {
    this.sourceFormat = sourceFormat;
  }
  
  public String getResponse() {
    return this.response;
  }
  
  public void setResponse(String response) {
    this.response = response;
  }
  
  public long getFilePollInterval() {
    return this.filePollInterval;
  }
  
  public void setFilePollInterval(long filePollInterval) {
    this.filePollInterval = filePollInterval;
  }
  
  public String getUrl() {
    return this.url;
  }
  
  public void setUrl(String url) {
    this.url = url;
  }
  
  public String getHttpMethod() {
    return this.httpMethod;
  }
  
  public void setHttpMethod(String httpMethod) {
    this.httpMethod = httpMethod;
  }
  
  public String getSecurityFile() {
    return this.securityFile;
  }
  
  public void setSecurityFile(String securityFile) {
    this.securityFile = securityFile;
  }
  
  public String getHeaderFile() {
	return this.headerFile;
}

public void setHeaderFile(String headerFile) {
	this.headerFile = headerFile;
}

public String getDigitalSignatureFile() {
    return this.digitalSignatureFile;
  }
  
  public void setDigitalSignatureFile(String digitalSignatureFile) {
    this.digitalSignatureFile = digitalSignatureFile;
  }
  
  public String getDriverClass() {
    return this.driverClass;
  }
  
  public void setDriverClass(String driverClass) {
    this.driverClass = driverClass;
  }
  
  public String getDbtype() {
    return this.dbtype;
  }
  
  public void setDbtype(String dbtype) {
    this.dbtype = dbtype;
  }
  
  public String getQuery() {
    return this.query;
  }
  
  public void setQuery(String query) {
    this.query = query;
  }
  
  public String getCleanQuery() {
    return this.cleanQuery;
  }
  
  public void setCleanQuery(String cleanQuery) {
    this.cleanQuery = cleanQuery;
  }
  
  public String getDbURL() {
    return this.dbURL;
  }
  
  public void setDbURL(String dbURL) {
    this.dbURL = dbURL;
  }
  
  public String getDbUser() {
    return this.dbUser;
  }
  
  public void setDbUser(String dbUser) {
    this.dbUser = dbUser;
  }
  
  public String getDbPassword() {
    return this.dbPassword;
  }
  
  public void setDbPassword(String dbPassword) {
    this.dbPassword = dbPassword;
  }
  
  public String getConnectionFactory() {
    return this.connectionFactory;
  }
  
  public void setConnectionFactory(String connectionFactory) {
    this.connectionFactory = connectionFactory;
  }
  
  public String getReplyToConnectionFactory() {
    return this.replyToConnectionFactory;
  }
  
  public void setReplyToConnectionFactory(String replyToConnectionFactory) {
    this.replyToConnectionFactory = replyToConnectionFactory;
  }
  
  public String getJmsConetxFactory() {
    return this.jmsConetxFactory;
  }
  
  public void setJmsConetxFactory(String jmsConetxFactory) {
    this.jmsConetxFactory = jmsConetxFactory;
  }
  
  public String getJmsProviderURL() {
    return this.jmsProviderURL;
  }
  
  public void setJmsProviderURL(String jmsProviderURL) {
    this.jmsProviderURL = jmsProviderURL;
  }
  
  public String getJmsByteMessageEncoding() {
    return this.jmsByteMessageEncoding;
  }
  
  public void setJmsByteMessageEncoding(String jmsByteMessageEncoding) {
    this.jmsByteMessageEncoding = jmsByteMessageEncoding;
  }
  
  public TestCaseDTO getTestCase() {
    return this.testCase;
  }
  
  public void setTestCase(TestCaseDTO testCase) {
    this.testCase = testCase;
  }
  
  public void setActualValueFromProperties(Properties properties) {
    this.host = (properties.getProperty("host") != null && properties.getProperty("host").trim().length() > 0) ? properties.getProperty("host").trim() : null;
    this.port = (properties.getProperty("port") != null && properties.getProperty("port").trim().length() > 0) ? Integer.parseInt(properties.getProperty("port").trim()) : 0;
    this.channel = (properties.getProperty("channel") != null && properties.getProperty("channel").trim().length() > 0) ? properties.getProperty("channel").trim() : "SYSTEM.DEF.SVRCONN";
    this.replyHost = (properties.getProperty("reply.host") != null && properties.getProperty("reply.host").trim().length() > 0) ? properties.getProperty("reply.host").trim() : this.host;
    this.replyPort = (properties.getProperty("reply.port") != null && properties.getProperty("reply.port").trim().length() > 0) ? Integer.parseInt(properties.getProperty("reply.port").trim()) : this.port;
    this.replyChannel = (properties.getProperty("reply.channel") != null && properties.getProperty("reply.channel").trim().length() > 0) ? properties.getProperty("reply.channel").trim() : this.channel;
    this.queueManagerName = (properties.getProperty("queue.manager") != null && properties.getProperty("queue.manager").trim().length() > 0) ? properties.getProperty("queue.manager").trim() : null;
    this.replyToQueueManager = (properties.getProperty("reply.queue.manager") != null && properties.getProperty("reply.queue.manager").trim().length() > 0) ? properties.getProperty("reply.queue.manager").trim() : this.queueManagerName;
    this.requestQueueName = (properties.getProperty("request.queue.name") != null && properties.getProperty("request.queue.name").trim().length() > 0) ? properties.getProperty("request.queue.name").trim() : null;
    this.responseQueueName = (properties.getProperty("reply.queue.name") != null && properties.getProperty("reply.queue.name").trim().length() > 0) ? properties.getProperty("reply.queue.name").trim() : null;
    this.correlationType = (properties.getProperty("correlation.type") != null && properties.getProperty("correlation.type").trim().length() > 0) ? properties.getProperty("correlation.type").trim() : "NONE";
    this.waitInterval = (properties.getProperty("wait.interval") != null && properties.getProperty("wait.interval").trim().length() > 0) ? Integer.parseInt(properties.getProperty("port").trim()) : 60000;
    this.ftpUser = (properties.getProperty("ftp.user") != null && properties.getProperty("ftp.user").trim().length() > 0) ? properties.getProperty("ftp.user").trim() : null;
    this.ftpPassword = (properties.getProperty("ftp.password") != null && properties.getProperty("ftp.password").trim().length() > 0) ? properties.getProperty("ftp.password").trim() : null;
    this.localDirectory = (properties.getProperty("local.directory") != null && properties.getProperty("local.directory").trim().length() > 0) ? properties.getProperty("local.directory").trim() : null;
    this.localFileName = (properties.getProperty("local.file.name") != null && properties.getProperty("local.file.name").trim().length() > 0) ? properties.getProperty("local.file.name").trim() : null;
    this.localPath = (properties.getProperty("local.path") != null && properties.getProperty("local.path").trim().length() > 0) ? properties.getProperty("local.path").trim() : null;
    this.remoteDirectory = (properties.getProperty("remote.directory") != null && properties.getProperty("remote.directory").trim().length() > 0) ? properties.getProperty("remote.directory").trim() : null;
    this.remoteFileName = (properties.getProperty("remote.file.name") != null && properties.getProperty("remote.file.name").trim().length() > 0) ? properties.getProperty("remote.file.name").trim() : null;
    this.remotePath = (properties.getProperty("remote.path") != null && properties.getProperty("remote.path").trim().length() > 0) ? properties.getProperty("remote.path").trim() : null;
    this.fileftpWaitInterval = ((properties.getProperty("file.wait.interval") != null && properties.getProperty("file.wait.interval").trim().length() > 0) ? Integer.parseInt(properties.getProperty("file.wait.interval").trim()) : 60000L);
    this.filePollInterval = ((properties.getProperty("file.poll.interval") != null && properties.getProperty("file.poll.interval").trim().length() > 0) ? Integer.parseInt(properties.getProperty("file.poll.interval").trim()) : 5000L);
    this.ftpRemoteDelete = (properties.getProperty("ftp.remote.delete.enabled") != null && properties.getProperty("ftp.remote.delete.enabled").trim().length() > 0) ? properties.getProperty("ftp.remote.delete.enabled").trim() : "FALSE";
    this.driverClass = (properties.getProperty("driver.class") != null && properties.getProperty("driver.class").trim().length() > 0) ? properties.getProperty("driver.class").trim() : null;
    this.dbtype = (properties.getProperty("db.type") != null && properties.getProperty("db.type").trim().length() > 0) ? properties.getProperty("db.type").trim() : null;
    this.query = (properties.getProperty("query") != null && properties.getProperty("query").trim().length() > 0) ? properties.getProperty("query").trim() : null;
    this.cleanQuery = (properties.getProperty("clean.query") != null && properties.getProperty("clean.query").trim().length() > 0) ? properties.getProperty("clean.query").trim() : null;
    this.dbURL = (properties.getProperty("db.url") != null && properties.getProperty("db.url").trim().length() > 0) ? properties.getProperty("db.url").trim() : null;
    this.dbUser = (properties.getProperty("db.user") != null && properties.getProperty("db.user").trim().length() > 0) ? properties.getProperty("db.user").trim() : null;
    this.dbPassword = (properties.getProperty("db.password") != null && properties.getProperty("db.password").trim().length() > 0) ? properties.getProperty("db.password").trim() : null;
    this.connectionFactory = (properties.getProperty("connection.factory") != null && properties.getProperty("connection.factory").trim().length() > 0) ? properties.getProperty("connection.factory").trim() : null;
    this.replyToConnectionFactory = (properties.getProperty("reply.connection.factory") != null && properties.getProperty("reply.connection.factory").trim().length() > 0) ? properties.getProperty("reply.connection.factory").trim() : this.connectionFactory;
    this.jmsConetxFactory = (properties.getProperty("jms.context.factory") != null && properties.getProperty("jms.context.factory").trim().length() > 0) ? properties.getProperty("jms.context.factory").trim() : "com.sun.jndi.fscontext.RefFSContextFactory";
    this.jmsProviderURL = (properties.getProperty("jms.provider.url") != null && properties.getProperty("jms.provider.url").trim().length() > 0) ? properties.getProperty("jms.provider.url").trim() : null;
    this.jmsByteMessageEncoding = (properties.getProperty("jms.byte.message.encoding") != null && properties.getProperty("jms.byte.message.encoding").trim().length() > 0) ? properties.getProperty("jms.byte.message.encoding").trim() : "UTF-8";
  }
  
  public void setLegacyValueFromProperties(Properties properties) {
    this.isLegacy = true;
    this.host = (properties.getProperty("legacy.host") != null && properties.getProperty("legacy.host").trim().length() > 0) ? properties.getProperty("legacy.host").trim() : null;
    this.port = (properties.getProperty("legacy.port") != null && properties.getProperty("legacy.port").trim().length() > 0) ? Integer.parseInt(properties.getProperty("legacy.port").trim()) : 0;
    this.channel = (properties.getProperty("legacy.channel") != null && properties.getProperty("legacy.channel").trim().length() > 0) ? properties.getProperty("legacy.channel").trim() : "SYSTEM.DEF.SVRCONN";
    this.replyHost = (properties.getProperty("legacy.reply.host") != null && properties.getProperty("legacy.reply.host").trim().length() > 0) ? properties.getProperty("legacy.reply.host").trim() : this.host;
    this.replyPort = (properties.getProperty("legacy.reply.port") != null && properties.getProperty("legacy.reply.port").trim().length() > 0) ? Integer.parseInt(properties.getProperty("legacy.reply.port").trim()) : this.port;
    this.replyChannel = (properties.getProperty("legacy.reply.channel") != null && properties.getProperty("legacy.reply.channel").trim().length() > 0) ? properties.getProperty("legacy.reply.channel").trim() : this.channel;
    this.queueManagerName = (properties.getProperty("legacy.queue.manager") != null && properties.getProperty("legacy.queue.manager").trim().length() > 0) ? properties.getProperty("legacy.queue.manager").trim() : null;
    this.replyToQueueManager = (properties.getProperty("legacy.reply.queue.manager") != null && properties.getProperty("legacy.reply.queue.manager").trim().length() > 0) ? properties.getProperty("legacy.reply.queue.manager").trim() : this.queueManagerName;
    this.requestQueueName = (properties.getProperty("legacy.request.queue.name") != null && properties.getProperty("legacy.request.queue.name").trim().length() > 0) ? properties.getProperty("legacy.request.queue.name").trim() : null;
    this.responseQueueName = (properties.getProperty("legacy.reply.queue.name") != null && properties.getProperty("legacy.reply.queue.name").trim().length() > 0) ? properties.getProperty("legacy.reply.queue.name").trim() : null;
    this.correlationType = (properties.getProperty("legacy.correlation.type") != null && properties.getProperty("legacy.correlation.type").trim().length() > 0) ? properties.getProperty("legacy.correlation.type").trim() : "NONE";
    this.waitInterval = (properties.getProperty("legacy.wait.interval") != null && properties.getProperty("legacy.wait.interval").trim().length() > 0) ? Integer.parseInt(properties.getProperty("legacy.wait.interval").trim()) : 60000;
    this.ftpUser = (properties.getProperty("legacy.ftp.user") != null && properties.getProperty("legacy.ftp.user").trim().length() > 0) ? properties.getProperty("legacy.ftp.user").trim() : null;
    this.ftpPassword = (properties.getProperty("legacy.ftp.password") != null && properties.getProperty("legacy.ftp.password").trim().length() > 0) ? properties.getProperty("legacy.ftp.password").trim() : null;
    this.localDirectory = (properties.getProperty("legacy.local.directory") != null && properties.getProperty("legacy.local.directory").trim().length() > 0) ? properties.getProperty("legacy.local.directory").trim() : null;
    this.localFileName = (properties.getProperty("legacy.local.file.name") != null && properties.getProperty("legacy.local.file.name").trim().length() > 0) ? properties.getProperty("legacy.local.file.name").trim() : null;
    this.localPath = (properties.getProperty("legacy.local.path") != null && properties.getProperty("legacy.local.path").trim().length() > 0) ? properties.getProperty("legacy.local.path").trim() : null;
    this.remoteDirectory = (properties.getProperty("legacy.remote.directory") != null && properties.getProperty("legacy.remote.directory").trim().length() > 0) ? properties.getProperty("legacy.remote.directory").trim() : null;
    this.remoteFileName = (properties.getProperty("legacy.remote.file.name") != null && properties.getProperty("legacy.remote.file.name").trim().length() > 0) ? properties.getProperty("legacy.remote.file.name").trim() : null;
    this.remotePath = (properties.getProperty("legacy.remote.path") != null && properties.getProperty("legacy.remote.path").trim().length() > 0) ? properties.getProperty("legacy.remote.path").trim() : null;
    this.fileftpWaitInterval = ((properties.getProperty("legacy.file.wait.interval") != null && properties.getProperty("legacy.file.wait.interval").trim().length() > 0) ? Integer.parseInt(properties.getProperty("legacy.file.wait.interval").trim()) : 60000L);
    this.filePollInterval = ((properties.getProperty("legacy.file.poll.interval") != null && properties.getProperty("legacy.file.poll.interval").trim().length() > 0) ? Integer.parseInt(properties.getProperty("legacy.file.poll.interval").trim()) : 5000L);
    this.ftpRemoteDelete = (properties.getProperty("legacy.ftp.remote.delete.enabled") != null && properties.getProperty("legacy.ftp.remote.delete.enabled").trim().length() > 0) ? properties.getProperty("legacy.ftp.remote.delete.enabled").trim() : "FALSE";
    this.driverClass = (properties.getProperty("legacy.driver.class") != null && properties.getProperty("legacy.driver.class").trim().length() > 0) ? properties.getProperty("legacy.driver.class").trim() : null;
    this.dbtype = (properties.getProperty("legacy.db.type") != null && properties.getProperty("legacy.db.type").trim().length() > 0) ? properties.getProperty("legacy.db.type").trim() : null;
    this.query = (properties.getProperty("legacy.query") != null && properties.getProperty("legacy.query").trim().length() > 0) ? properties.getProperty("legacy.query").trim() : null;
    this.cleanQuery = (properties.getProperty("legacy.clean.query") != null && properties.getProperty("legacy.clean.query").trim().length() > 0) ? properties.getProperty("legacy.clean.query").trim() : null;
    this.dbURL = (properties.getProperty("legacy.db.url") != null && properties.getProperty("legacy.db.url").trim().length() > 0) ? properties.getProperty("legacy.db.url").trim() : null;
    this.dbUser = (properties.getProperty("legacy.db.user") != null && properties.getProperty("legacy.db.user").trim().length() > 0) ? properties.getProperty("legacy.db.user").trim() : null;
    this.dbPassword = (properties.getProperty("legacy.db.password") != null && properties.getProperty("legacy.db.password").trim().length() > 0) ? properties.getProperty("legacy.db.password").trim() : null;
    this.connectionFactory = (properties.getProperty("legacy.connection.factory") != null && properties.getProperty("legacy.connection.factory").trim().length() > 0) ? properties.getProperty("legacy.connection.factory").trim() : null;
    this.replyToConnectionFactory = (properties.getProperty("legacy.reply.connection.factory") != null && properties.getProperty("legacy.reply.connection.factory").trim().length() > 0) ? properties.getProperty("legacy.reply.connection.factory").trim() : this.connectionFactory;
    this.jmsConetxFactory = (properties.getProperty("legacy.jms.context.factory") != null && properties.getProperty("legacy.jms.context.factory").trim().length() > 0) ? properties.getProperty("legacy.jms.context.factory").trim() : "com.sun.jndi.fscontext.RefFSContextFactory";
    this.jmsProviderURL = (properties.getProperty("legacy.jms.provider.url") != null && properties.getProperty("legacy.jms.provider.url").trim().length() > 0) ? properties.getProperty("legacy.jms.provider.url").trim() : null;
    this.jmsByteMessageEncoding = (properties.getProperty("legacy.jms.byte.message.encoding") != null && properties.getProperty("legacy.jms.byte.message.encoding").trim().length() > 0) ? properties.getProperty("legacy.jms.byte.message.encoding").trim() : "UTF-8";
  }
  
  public void setActualValuesFromTestCase(TestCaseDTO tcDTO) throws Exception {
    this.testInputFileLocation = tcDTO.getInput();
    this.testOutputFileLocation = tcDTO.getActualOutput();
    this.targetFormat = tcDTO.getTargetFormat();
    this.sourceFormat = tcDTO.getSourceFormat();
    this.url = tcDTO.getEndpoint();
    this.securityFile = tcDTO.getSecurityInfo();
    this.headerFile = tcDTO.getHeaderInfo();
    this.digitalSignatureFile = tcDTO.getDigitalSignatureInfo();
    this.testInputFileLocation = FileUtil.confirmAbsoluteInputFileName(this.testInputFileLocation);
    this.message = FileUtil.readFileAsString(this.testInputFileLocation);
    if ("HTTPGET".equalsIgnoreCase(tcDTO.getSourceProtocol()) || 
      "HTTPGET".equalsIgnoreCase(tcDTO.getTargetProtocol())) {
      this.httpMethod = "GET";
    } else if ("HTTPPOST".equalsIgnoreCase(tcDTO.getSourceProtocol()) || 
      "HTTP".equalsIgnoreCase(tcDTO.getSourceProtocol()) || 
      "HTTPPOST".equalsIgnoreCase(tcDTO.getTargetProtocol()) || 
      "HTTP".equalsIgnoreCase(tcDTO.getTargetProtocol())) {
      this.httpMethod = "POST";
    } 
  }
  
  public void setLegacyValuesFromTestCase(TestCaseDTO tcDTO) throws Exception {
    this.testInputFileLocation = tcDTO.getInput();
    this.testOutputFileLocation = tcDTO.getExpectedOutput();
    this.targetFormat = tcDTO.getTargetFormat();
    this.sourceFormat = tcDTO.getSourceFormat();
    this.url = tcDTO.getLegacyEndPont();
    this.securityFile = tcDTO.getSecurityInfo();
    this.headerFile = tcDTO.getHeaderInfo();
    this.digitalSignatureFile = tcDTO.getDigitalSignatureInfo();
    this.testInputFileLocation = FileUtil.confirmAbsoluteInputFileName(this.testInputFileLocation);
    this.message = FileUtil.readFileAsString(this.testInputFileLocation);
    if ("HTTPGET".equalsIgnoreCase(tcDTO.getSourceProtocol()) || 
      "HTTPGET".equalsIgnoreCase(tcDTO.getTargetProtocol())) {
      this.httpMethod = "GET";
    } else if ("HTTPPOST".equalsIgnoreCase(tcDTO.getSourceProtocol()) || 
      "HTTP".equalsIgnoreCase(tcDTO.getSourceProtocol()) || 
      "HTTPPOST".equalsIgnoreCase(tcDTO.getTargetProtocol()) || 
      "HTTP".equalsIgnoreCase(tcDTO.getTargetProtocol())) {
      this.httpMethod = "POST";
    } 
  }


}
