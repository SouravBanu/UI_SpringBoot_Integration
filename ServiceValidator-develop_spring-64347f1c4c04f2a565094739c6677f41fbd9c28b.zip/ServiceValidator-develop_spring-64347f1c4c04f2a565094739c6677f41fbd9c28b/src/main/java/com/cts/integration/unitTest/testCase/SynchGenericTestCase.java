package com.cts.integration.unitTest.testCase;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import com.cts.integration.dto.TestCaseDTO;
import com.cts.integration.assertion.IJunitAssertion;
import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.IJunitTestCase;
import com.cts.integration.factory.AssertionFactory;
import com.cts.integration.factory.ClientFactory;
import com.cts.integration.unitTest.client.IJunitClient;
import com.cts.integration.util.FileUtil;

import junit.framework.TestCase;

public class SynchGenericTestCase extends TestCase {
	
	TestCaseDTO testCase;
	  
	  public SynchGenericTestCase(String testName, TestCaseDTO testCase) {
	    super(testName);
	    this.testCase = testCase;
	  }
	  
	  static Logger log = Logger.getLogger(SynchGenericTestCase.class.getName());
	  
	  public TestCaseDTO getTestCase() {
	    return this.testCase;
	  }
	  
	  public void setTestCase(TestCaseDTO testCase) {
	    this.testCase = testCase;
	  }
	
	public void test() throws Exception{
		log.info("Executing Synch Test");
		FileInputStream inputPropInputStream = null;
		FileInputStream outputPropInputStream = null;
		String expectdResponse = null;
		
		try{
			ComplexRequestDTO requestDTO = new ComplexRequestDTO();
			ComplexRequestDTO legacyRequestDTO = null;
			
			
			
  	        //String sourceInfo = IJunitTestCase.testCase.getSourceInfo();
  	        //String targetInfo = IJunitTestCase.testCase.getTargetInfo();
			String sourceInfo = testCase.getSourceInfo();
  	        
  	        File inputPropertiesFile = new File(sourceInfo);
	        Properties inputProperties = new Properties();
	        if(inputPropertiesFile.exists()){
	        	log.info("loading source properties file");
	        	inputPropInputStream = new FileInputStream(inputPropertiesFile);
	        	inputProperties.load(inputPropInputStream);
	        }
	        
	        	        
	        //prepare request
	        requestDTO.setActualValueFromProperties(inputProperties);
	       // requestDTO.setActualValuesFromTestCase(IJunitTestCase.testCase);
	        requestDTO.setActualValuesFromTestCase(testCase);
	       
	        
	        //get client from facotry
	        //IJunitClient client = ClientFactory.getClient(IJunitTestCase.testCase.getSourceProtocol());
	        IJunitClient client = ClientFactory.getClient(testCase.getSourceProtocol());
	        log.debug("Got source Client "+client);
	        //clean any inputQueue/directory prior to Test
	        //client.cleanResponseContainer(requestDTO);
	        	        
	        //invoke Test
	        client.synchCall(requestDTO);
	        log.info("Syncronous call executed");	        	        
	        //check for legacy mode/comparison mode
	        //String asIsURL = IJunitTestCase.testCase.getLegacyEndPont();
	        String asIsURL = testCase.getLegacyEndPont();
	        if(
	        		(inputProperties.getProperty("LEGACY")!=null 
	        		&& "TRUE".equalsIgnoreCase(inputProperties.getProperty("LEGACY").trim())
	        		)
	        		||
	        		(asIsURL!=null && asIsURL.trim().length()>0)
	        		){
  	        	
	        	log.info("Retrieving expected response from Legacy(As-is)");
  	        	legacyRequestDTO = new ComplexRequestDTO();
  				  				
  				 //prepare legacy request and response
  				legacyRequestDTO.setLegacyValueFromProperties(inputProperties);
  				//legacyRequestDTO.setLegacyValuesFromTestCase(IJunitTestCase.testCase);
  				legacyRequestDTO.setLegacyValuesFromTestCase(testCase);
  				  				
  				//client.cleanResponseContainer(legacyRequestDTO);
  		          		        
  		        //invoke legacy Test
  		        client.synchCall(legacyRequestDTO);
  		        log.info("Syncronous call executed on Legacy system");
  		         		        
  		        
  		        //get legacy response
  		        expectdResponse = legacyRequestDTO.getResponse();
  	        }else{
  	        	
  	        	//String expectdPath = FileUtil.confirmAbsoluteInputFileName(IJunitTestCase.testCase.getExpectedOutput());
  	        	String expectdPath = FileUtil.confirmAbsoluteInputFileName(testCase.getExpectedOutput());
  	        	expectdResponse = FileUtil.readFileAsString(expectdPath);
  	        	log.info("Retrieved expected response from Test Case configuration");
  	        }
	        
	        //IJunitAssertion assertion = AssertionFactory.getAssertion(IJunitTestCase.testCase.getTargetFormat());
	        IJunitAssertion assertion = AssertionFactory.getAssertion(testCase.getTargetFormat());
	        log.info("Got assertion object "+assertion);
	        if(assertion != null){
	        	//assertion.assertEquals(expectdResponse, requestDTO.getResponse(),IJunitTestCase.testCase.getIgnoreList());
	        	assertion.assertEquals(expectdResponse, requestDTO.getResponse(),testCase.getIgnoreList());
	        }else{
	        	log.info("Performing Default Assertion");
	        	assertEquals(expectdResponse, requestDTO.getResponse());
	        }
	        
	        
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally{
			if(inputPropInputStream != null){
				inputPropInputStream.close();
			}
			if(outputPropInputStream != null){
				outputPropInputStream.close();
			}
		}
	}
}
