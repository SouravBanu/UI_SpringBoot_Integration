package com.cts.integration.util;

import com.cts.integration.dto.TestCaseDTO;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {
  static Logger log = Logger.getLogger(ExcelUtil.class.getName());
  
  public static void main(String[] a) throws Exception {
    System.out.println(readExcel("D:/JunitTest/IJUnitTest.xlsx"));
  }
  
  public static List<TestCaseDTO> readExcel(String ExcelLocation) throws Exception {
    log.info("Reading excel : " + ExcelLocation);
    List<TestCaseDTO> testCases = new ArrayList<TestCaseDTO>();
    FileInputStream file = null;
    try {
      file = new FileInputStream(new File(ExcelLocation));
      XSSFWorkbook workbook = new XSSFWorkbook(file);
      XSSFSheet sheet = workbook.getSheet("TestCases");
      Iterator<Row> rowIterator = sheet.iterator();
      while (rowIterator.hasNext()) {
        Row row = rowIterator.next();
        if (row.getCell(1) != null && row.getCell(1).getStringCellValue().trim().length() != 0) {
          TestCaseDTO testCase = new TestCaseDTO();
          testCase.setTestCase((row.getCell(1) != null) ? row.getCell(1).getStringCellValue() : null);
          testCase.setDescription((row.getCell(2) != null) ? row.getCell(2).getStringCellValue() : null);
          testCase.setPattern((row.getCell(3) != null) ? row.getCell(3).getStringCellValue() : null);
          testCase.setSourceProtocol((row.getCell(4) != null) ? row.getCell(4).getStringCellValue() : null);
          testCase.setSourceFormat((row.getCell(5) != null) ? row.getCell(5).getStringCellValue() : null);
          testCase.setTargetProtocol((row.getCell(6) != null) ? row.getCell(6).getStringCellValue() : null);
          testCase.setTargetFormat((row.getCell(7) != null) ? row.getCell(7).getStringCellValue() : null);
          testCase.setSecurityInfo((row.getCell(8) != null) ? row.getCell(8).getStringCellValue() : null);
          testCase.setEndpoint((row.getCell(9) != null) ? row.getCell(9).getStringCellValue() : null);
          testCase.setLegacyEndPont((row.getCell(10) != null) ? row.getCell(10).getStringCellValue() : null);
          testCase.setSourceInfo((row.getCell(11) != null) ? row.getCell(11).getStringCellValue() : null);
          testCase.setTargetInfo((row.getCell(12) != null) ? row.getCell(12).getStringCellValue() : null);
          testCase.setInput((row.getCell(13) != null) ? row.getCell(13).getStringCellValue() : null);
          testCase.setExpectedOutput((row.getCell(14) != null) ? row.getCell(14).getStringCellValue() : null);
          testCase.setActualOutput((row.getCell(15) != null) ? row.getCell(15).getStringCellValue() : null);
          testCase.setDigitalSignatureInfo((row.getCell(16) != null) ? row.getCell(16).getStringCellValue() : null);
          String ignoredElements = (row.getCell(17) != null) ? row.getCell(17).getStringCellValue() : null;
          if (ignoredElements != null && ignoredElements.trim().length() > 0) {
            StringTokenizer st = new StringTokenizer(ignoredElements.trim(), ",");
            while (st.hasMoreElements())
              testCase.getIgnoreList().add((String)st.nextElement()); 
          } 
          testCase.setIsActive((row.getCell(18) != null) ? row.getCell(18).getStringCellValue() : "ACTIVE");
          testCases.add(testCase);
        } 
      } 
    } catch (Exception e) {
      log.info("Exception in reading excel : " + e.getMessage());
      e.printStackTrace();
      throw e;
    } finally {
      if (file != null)
        file.close(); 
    } 
    return testCases;
  }
}
