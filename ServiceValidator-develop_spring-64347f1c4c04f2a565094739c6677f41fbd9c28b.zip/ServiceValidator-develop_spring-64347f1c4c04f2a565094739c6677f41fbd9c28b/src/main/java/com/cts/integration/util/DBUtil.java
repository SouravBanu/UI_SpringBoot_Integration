package com.cts.integration.util;

import com.cts.integration.dto.TestCaseDTO;
import com.cts.integration.dto.TestConfDTO;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;
import org.apache.log4j.Logger;

public class DBUtil {
  static Logger log = Logger.getLogger(DBUtil.class.getName());
  
  public static void reportToDB(TestConfDTO confDTO, List<TestCaseDTO> testCases) throws Exception {
    log.info("Inserting results to Database");
    Connection con = null;
    PreparedStatement stat = null;
    String SQL_INSERT = "Insert into TEST_REPORT values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    try {
      String testLot = UUID.randomUUID().toString();
      Class.forName(confDTO.getDbdriverClass());
      if (confDTO.getDbUser() == null || confDTO.getDbUser().trim().length() == 0) {
        con = DriverManager.getConnection(confDTO.getDbURL());
      } else {
        con = DriverManager.getConnection(confDTO.getDbURL(), confDTO.getDbUser(), confDTO.getDbPassword());
      } 
      con.setAutoCommit(false);
      stat = con.prepareStatement(SQL_INSERT);
      int i = 0;
      for (TestCaseDTO testCase : testCases) {
        String id = UUID.randomUUID().toString();
        String input = FileUtil.getMessageIfFileExists(testCase.getInput());
        String outPut = FileUtil.getMessageIfFileExists(testCase.getActualOutput());
        String expectedOutput = FileUtil.getMessageIfFileExists(testCase.getExpectedOutput());
        String reason = testCase.getReason();
        String empty = "";
        StringReader emptyReader = new StringReader(empty);
        StringReader inputReader = (input != null) ? new StringReader(input) : emptyReader;
        StringReader outputReader = (outPut != null) ? new StringReader(outPut) : emptyReader;
        StringReader expectedOutputReader = (expectedOutput != null) ? new StringReader(expectedOutput) : emptyReader;
        StringReader reasonReader = (reason != null) ? new StringReader(reason) : emptyReader;
        int emptyLength = empty.length();
        int inputLength = (input != null) ? input.length() : emptyLength;
        int outputLength = (outPut != null) ? outPut.length() : emptyLength;
        int expectedOutputLength = (expectedOutput != null) ? expectedOutput.length() : emptyLength;
        int reasonLength = (reason != null) ? reason.length() : emptyLength;
        stat.setString(1, id);
        stat.setString(2, testCase.getTestCase());
        stat.setString(3, testCase.getSourceProtocol());
        stat.setString(4, testCase.getPattern());
        stat.setString(5, testCase.getSourceFormat());
        stat.setString(6, testCase.getTargetProtocol());
        stat.setString(7, testCase.getTargetFormat());
        stat.setString(8, testCase.getEndpoint());
        stat.setString(9, testCase.getLegacyEndPont());
        stat.setString(10, (new Boolean(testCase.isRerun())).toString());
        stat.setString(11, (new Boolean(testCase.isPassed())).toString());
        stat.setTimestamp(12, new Timestamp(testCase.getExecutedAt()));
        stat.setCharacterStream(13, inputReader, inputLength);
        stat.setCharacterStream(14, outputReader, outputLength);
        stat.setCharacterStream(15, expectedOutputReader, expectedOutputLength);
        stat.setCharacterStream(16, reasonReader, reasonLength);
        stat.setString(17, testLot);
        stat.addBatch();
        i++;
        if (i % 1000 == 0 || i == testCases.size())
          stat.executeBatch(); 
      } 
    } catch (Exception e) {
      log.error("Exception Inserting results to Database " + e.getMessage());
      e.printStackTrace();
    } finally {
      if (stat != null)
        stat.close(); 
      if (con != null) {
        con.commit();
        con.close();
      } 
    } 
  }
}
